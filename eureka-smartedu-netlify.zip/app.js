const { useState, useEffect, useRef, useMemo } = React;

// Google OAuth 2.0 Client ID
const GOOGLE_CLIENT_ID = "484190105845-7hmcoq9ped5uo5m20cjlok37curofrn0.apps.googleusercontent.com";

// Decode Google JWT Token securely
function parseJwt(token) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch (e) {
    console.error("Failed to parse Google JWT credential:", e);
    return null;
  }
}

// --- SVG ICON SYSTEM ---
function Icon({ name, className = "w-4 h-4", size = 18 }) {
  const icons = {
    'graduation-cap': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
        <path d="M6 12v5c3 3 9 3 12 0v-5" />
      </svg>
    ),
    'zap': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="currentColor" stroke="none">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
      </svg>
    ),
    'search': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
      </svg>
    ),
    'star': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="1">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
      </svg>
    ),
    'check': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 6 9 17 4 12" />
      </svg>
    ),
    'check-circle': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
        <polyline points="22 4 12 14.01 9 11.01" />
      </svg>
    ),
    'shield': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      </svg>
    ),
    'shield-check': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
        <path d="m9 12 2 2 4-4" />
      </svg>
    ),
    'book-open': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
      </svg>
    ),
    'calendar': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
        <line x1="16" y1="2" x2="16" y2="6" />
        <line x1="8" y1="2" x2="8" y2="6" />
        <line x1="3" y1="10" x2="21" y2="10" />
      </svg>
    ),
    'heart': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
      </svg>
    ),
    'crown': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14" />
      </svg>
    ),
    'camera': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" />
        <circle cx="12" cy="13" r="3" />
      </svg>
    ),
    'user': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
      </svg>
    ),
    'users': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
    'mail': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect width="20" height="16" x="2" y="4" rx="2" />
        <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
      </svg>
    ),
    'phone': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
      </svg>
    ),
    'file-text': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
        <polyline points="14 2 14 8 20 8" />
        <line x1="16" x2="8" y1="13" y2="13" />
        <line x1="16" x2="8" y1="17" y2="17" />
        <line x1="10" x2="8" y1="9" y2="9" />
      </svg>
    ),
    'video': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polygon points="23 7 16 12 23 17 23 7" />
        <rect x="1" y="5" width="15" height="14" rx="2" ry="2" />
      </svg>
    ),
    'video-off': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34l1 1L23 7v10" />
        <line x1="1" y1="1" x2="23" y2="23" />
      </svg>
    ),
    'mic': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" />
        <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
        <line x1="12" y1="19" x2="12" y2="23" />
        <line x1="8" y1="23" x2="16" y2="23" />
      </svg>
    ),
    'mic-off': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="1" y1="1" x2="23" y2="23" />
        <path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6" />
        <path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23" />
        <line x1="12" y1="19" x2="12" y2="23" />
        <line x1="8" y1="23" x2="16" y2="23" />
      </svg>
    ),
    'hand': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M18 11V6a2 2 0 0 0-4 0v5" />
        <path d="M14 10V4a2 2 0 0 0-4 0v6" />
        <path d="M10 10.5V6a2 2 0 0 0-4 0v8" />
        <path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-16 0v-1.5" />
      </svg>
    ),
    'arrow-right': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
      </svg>
    ),
    'x': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
      </svg>
    ),
    'moon': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
      </svg>
    ),
    'sun': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="5" />
        <line x1="12" y1="1" x2="12" y2="3" />
        <line x1="12" y1="21" x2="12" y2="23" />
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
        <line x1="1" y1="12" x2="3" y2="12" />
        <line x1="21" y1="12" x2="23" y2="12" />
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
      </svg>
    ),
    'pen-tool': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m12 19 7-7 3 3-7 7-3-3z" />
        <path d="m18 13-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
        <circle cx="11" cy="11" r="2" />
      </svg>
    ),
    'eraser': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21" />
        <path d="M22 21H7" />
        <path d="m5 11 9 9" />
      </svg>
    ),
    'send': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="22" y1="2" x2="11" y2="13" />
        <polygon points="22 2 15 22 11 13 2 9 22 2" />
      </svg>
    ),
    'coins': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="8" cy="8" r="6" />
        <path d="M18.09 10.37A6 6 0 1 1 10.34 18" />
        <path d="M7 6h1v4" />
      </svg>
    ),
    'eye': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
      </svg>
    ),
    'eye-off': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
        <line x1="1" y1="1" x2="23" y2="23" />
      </svg>
    ),
    'award': (
      <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="8" r="7" />
        <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88" />
      </svg>
    )
  };
  return icons[name] || <span className="inline-block w-4 h-4 bg-slate-300 rounded"></span>;
}

// Brand Logo Component using dynamic Light/Dark theme logo
function BrandLogo({ size = "normal" }) {
  const isLarge = size === "large";
  return (
    <div className="flex items-center space-x-2 cursor-pointer select-none">
      <img
        src="logo-light.png"
        alt="Lunexa"
        className={`dark:hidden ${isLarge ? 'h-14' : 'h-12'} w-auto object-contain`}
      />
      <img
        src="logo-full.png"
        alt="Lunexa"
        className={`hidden dark:block ${isLarge ? 'h-14' : 'h-12'} w-auto object-contain`}
      />
    </div>
  );
}

// Mock Data
const MENTORS = [
  {
    id: 1,
    name: "Aman Gupta",
    college: "IIT Delhi",
    year: "CSE Year 3",
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80",
    online: true,
    rating: 4.95,
    reviewsCount: 68,
    subjects: ["JEE Physics", "Calculus", "Mechanics"],
    hourlyRate: 300,
    batchBadge: "Batch starts Tomorrow • 15/20 Seats Filled",
    bio: "AIR 184 in JEE Advanced 2023. Passionate about deconstructing tough rotational mechanics & multivariate calculus for Class 11-12 students.",
    impactXp: 2840,
    hoursTaught: 84,
    category: "Physics"
  },
  {
    id: 2,
    name: "Priya Nair",
    college: "BITS Pilani",
    year: "ECE Year 2",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80",
    online: true,
    rating: 4.92,
    reviewsCount: 52,
    subjects: ["Coding", "Python", "Data Structures"],
    hourlyRate: 250,
    batchBadge: "Python Bootcamp starts in 3 Days",
    bio: "Google Summer of Code Scholar & ICPC Regionalist. Love teaching algorithms through real-world visual building blocks and interactive debugging.",
    impactXp: 2150,
    hoursTaught: 62,
    category: "CS"
  },
  {
    id: 3,
    name: "Rahul Sharma",
    college: "IIT Bombay",
    year: "Mechanical Year 4",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80",
    online: true,
    rating: 4.98,
    reviewsCount: 114,
    subjects: ["Calculus", "JEE Maths", "Coordinate Geometry"],
    hourlyRate: 0,
    batchBadge: "Free Doubt Session this Sunday",
    bio: "Rank 92 in JEE Main. Conducting weekly free doubt resolution drives for underprivileged school aspirants. Solved over 600 doubts.",
    impactXp: 3400,
    hoursTaught: 120,
    category: "Maths"
  },
  {
    id: 4,
    name: "Ananya Iyer",
    college: "AIIMS New Delhi",
    year: "MBBS Year 2",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80",
    online: false,
    rating: 4.88,
    reviewsCount: 41,
    subjects: ["Biology", "NEET Botany", "Human Physiology"],
    hourlyRate: 200,
    batchBadge: "NEET Sprint Batch: 8/15 Filled",
    bio: "NEET 2023 score 695/720. Mentoring future doctors on NCERT line-by-line decoding and diagrammatic memory mnemonics.",
    impactXp: 1680,
    hoursTaught: 48,
    category: "Biology"
  },
  {
    id: 5,
    name: "Devansh Patel",
    college: "NIT Trichy",
    year: "Chemical Year 3",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80",
    online: true,
    rating: 4.85,
    reviewsCount: 37,
    subjects: ["Chemistry", "Organic Chemistry", "Thermodynamics"],
    hourlyRate: 150,
    batchBadge: "Crash Batch • 11/15 Seats Filled",
    bio: "Organic reaction mechanisms simplified with intuitive electron-pushing methods. No more blind memorizing of reactions!",
    impactXp: 1320,
    hoursTaught: 39,
    category: "Chemistry"
  },
  {
    id: 6,
    name: "Sneha Mukherjee",
    college: "Delhi University",
    year: "B.Sc Maths Year 3",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80",
    online: true,
    rating: 4.90,
    reviewsCount: 49,
    subjects: ["Maths", "Class 10 CBSE", "Trigonometry"],
    hourlyRate: 0,
    batchBadge: "Class 10 Board Prep Weekly Batch",
    bio: "100/100 in Class 10 & 12 Board Mathematics. Committed to eliminating math anxiety for middle & high school kids.",
    impactXp: 1950,
    hoursTaught: 55,
    category: "Maths"
  }
];

const BATCHES = [
  {
    id: 1,
    title: "Mastering JEE Advanced Calculus in 4 Weeks",
    instructor: "Aman Gupta (IIT Delhi)",
    instructorAvatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&auto=format&fit=crop&q=80",
    schedule: "Tue & Thu • 7:00 PM IST",
    seatsTotal: 20,
    seatsFilled: 16,
    price: 499,
    category: "Maths",
    rating: 4.95,
    studentsEnrolled: 86
  },
  {
    id: 2,
    title: "Zero to Hero: Python & Algorithms for Junior Coders",
    instructor: "Priya Nair (BITS Pilani)",
    instructorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80",
    schedule: "Mon, Wed, Fri • 6:00 PM IST",
    seatsTotal: 25,
    seatsFilled: 22,
    price: 399,
    category: "CS",
    rating: 4.92,
    studentsEnrolled: 110
  },
  {
    id: 3,
    title: "High-Yield Organic Chemistry Mechanisms for NEET 2026",
    instructor: "Devansh Patel (NIT Trichy)",
    instructorAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80",
    schedule: "Sat & Sun • 11:00 AM IST",
    seatsTotal: 15,
    seatsFilled: 11,
    price: 299,
    category: "Chemistry",
    rating: 4.86,
    studentsEnrolled: 64
  }
];

// --- MAIN APPLICATION ROOT ---
function App() {
  const [theme, setTheme] = useState('light');
  const [currentView, setCurrentView] = useState('landing'); // 'landing', 'find-tutors', 'batches', 'how-it-works', 'pricing', 'dashboard', 'live-room', 'mentor-register'
  const [userRole, setUserRole] = useState('student'); // 'student' or 'mentor'
  const [currentUser, setCurrentUser] = useState(null); // { name, email, avatar, role }

  // Modals & State
  const [activeModal, setActiveModal] = useState(null); // 'auth', 'booking', 'profile'
  const [selectedMentor, setSelectedMentor] = useState(null);
  const [toast, setToast] = useState(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [modeFilter, setModeFilter] = useState('all');
  const [maxPrice, setMaxPrice] = useState(500);

  // Student State
  const [studentCoins, setStudentCoins] = useState(250);
  const [upcomingSessions, setUpcomingSessions] = useState([
    {
      id: 1,
      mentorName: "Rahul Sharma",
      college: "IIT Bombay",
      topic: "Calculus - Integration by Parts",
      time: "Today, 5:30 PM",
      status: "Confirmed"
    }
  ]);
  const [enrolledBatches, setEnrolledBatches] = useState([BATCHES[0]]);

  // Mentor State
  const [pendingRequests, setPendingRequests] = useState([
    {
      id: 101,
      studentName: "Kavya Mehra",
      grade: "Class 12 CBSE",
      topic: "Rotational Dynamics & Torque",
      time: "Tomorrow, 6:00 PM",
      tokenOffer: "₹300"
    }
  ]);

  // Toast Trigger
  const showToast = (message, icon = "") => {
    setToast({ message, icon, id: Date.now() });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    if (next === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  };

  // Filtered mentors
  const filteredMentors = useMemo(() => {
    return MENTORS.filter(m => {
      const matchQ = m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.college.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.subjects.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchCat = selectedCategory === 'All' || m.category === selectedCategory || m.subjects.some(s => s.toLowerCase().includes(selectedCategory.toLowerCase()));
      const matchMode = modeFilter === 'all' || modeFilter === '1on1' || (modeFilter === 'batches' && m.batchBadge);
      const matchPrice = m.hourlyRate <= maxPrice;
      return matchQ && matchCat && matchMode && matchPrice;
    });
  }, [searchQuery, selectedCategory, modeFilter, maxPrice]);

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${theme === 'dark' ? 'dark bg-[#0B0F19] text-slate-100' : 'bg-[#F8FAFC] text-slate-800'}`}>

      {/* 1. TOP NAVBAR (Matches Image 5 & Image 4) */}
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 py-3 flex items-center justify-between gap-4">

          {/* Logo */}
          <div className="flex items-center">
            <div onClick={() => setCurrentView(currentUser ? 'dashboard' : 'landing')} className="cursor-pointer">
              <BrandLogo />
            </div>
          </div>

          {/* Center Links */}
          <nav className="hidden md:flex items-center space-x-1">
            {[
              { id: 'landing', label: 'Home' },
              { id: 'find-tutors', label: 'Find Tutors' },
              { id: 'batches', label: 'Batch Classes' },
              { id: 'how-it-works', label: 'How It Works' },
              { id: 'pricing', label: 'Pricing & Free Trial' },
              { id: 'dashboard', label: userRole === 'student' ? 'Student Desk' : 'Mentor Hub' }
            ].map(tab => {
              const isActive = currentView === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setCurrentView(tab.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-xl transition-all ${isActive
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* Right Controls */}
          <div className="flex items-center space-x-2.5">
            {/* Search Input */}
            <div className="hidden lg:flex items-center relative">
              <Icon name="search" className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none" />
              <input
                type="text"
                placeholder="Search subjects..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (currentView !== 'find-tutors') setCurrentView('find-tutors');
                }}
                className="w-44 pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              title="Toggle Light/Dark"
            >
              {theme === 'light' ? <Icon name="moon" className="w-4 h-4" /> : <Icon name="sun" className="w-4 h-4" />}
            </button>

            {/* Log In & Sign Up / User Profile Avatar */}
            {currentUser ? (
              <div className="flex items-center space-x-2">
                <div
                  onClick={() => setCurrentView('dashboard')}
                  className="flex items-center space-x-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer transition-all"
                  title="Go to Dashboard"
                >
                  {currentUser.avatar ? (
                    <img src={currentUser.avatar} alt={currentUser.name} className="w-5 h-5 rounded-full object-cover ring-1 ring-indigo-500" />
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-bold">
                      {currentUser.name ? currentUser.name[0] : 'U'}
                    </div>
                  )}
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-100 max-w-[100px] truncate">
                    {currentUser.name}
                  </span>
                  <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                    {currentUser.role || userRole}
                  </span>
                </div>
                <button
                  onClick={() => {
                    setCurrentUser(null);
                    showToast("Logged out successfully", "");
                  }}
                  className="p-1.5 text-xs text-slate-400 hover:text-rose-500 dark:hover:text-rose-400 transition-colors"
                  title="Log Out"
                >
                  <Icon name="x" className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <>
                <button
                  onClick={() => setActiveModal('auth')}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-indigo-600 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
                >
                  Log In
                </button>
                <button
                  onClick={() => setActiveModal('auth')}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-[#4F46E5] hover:bg-[#4338CA] rounded-xl shadow-sm transition-all shadow-indigo-600/20"
                >
                  Sign Up
                </button>
              </>
            )}
          </div>

        </div>
      </header>

      {/* 2. MAIN CONTENT VIEW ROUTER */}
      <main className="flex-1">
        {currentView === 'landing' && !currentUser && (
          <LunexaLandingPage
            onFindMentor={() => setCurrentView('find-tutors')}
            onRegisterMentor={() => setCurrentView('mentor-register')}
            onOpenPricing={() => setCurrentView('pricing')}
            onOpenLiveRoom={() => setCurrentView('live-room')}
            mentors={MENTORS}
            batches={BATCHES}
            onSelectMentor={(m) => {
              setSelectedMentor(m);
              setActiveModal('booking');
            }}
          />
        )}

        {currentView === 'landing' && currentUser && (
          // Logged-in users should never see landing — show dashboard instead
          <DualDashboardView
            role={userRole}
            studentCoins={studentCoins}
            setStudentCoins={setStudentCoins}
            upcomingSessions={upcomingSessions}
            enrolledBatches={enrolledBatches}
            pendingRequests={pendingRequests}
            onAcceptRequest={(r) => {
              setPendingRequests(pendingRequests.filter(item => item.id !== r.id));
              setUpcomingSessions([
                ...upcomingSessions,
                { id: Date.now(), mentorName: "You (Mentor)", college: "IIT Bombay", topic: r.topic, time: r.time, status: "Confirmed" }
              ]);
              showToast(`Accepted session with ${r.studentName}!`, "");
            }}
            onDeclineRequest={(r) => {
              setPendingRequests(pendingRequests.filter(item => item.id !== r.id));
              showToast(`Declined request from ${r.studentName}`, "");
            }}
            onJoinLive={() => setCurrentView('live-room')}
          />
        )}

        {currentView === 'pricing' && (
          <LunexaPricingPage
            onStartFree={() => setCurrentView('find-tutors')}
            onFindMentor={() => setCurrentView('find-tutors')}
            onBrowseBatches={() => setCurrentView('batches')}
          />
        )}

        {currentView === 'find-tutors' && (
          <MentorDiscoveryPage
            mentors={filteredMentors}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            modeFilter={modeFilter}
            setModeFilter={setModeFilter}
            maxPrice={maxPrice}
            setMaxPrice={setMaxPrice}
            onBookMentor={(m) => {
              setSelectedMentor(m);
              setActiveModal('booking');
            }}
            onViewProfile={(m) => {
              setSelectedMentor(m);
              setActiveModal('profile');
            }}
          />
        )}

        {currentView === 'batches' && (
          <BatchClassesPage
            batches={BATCHES}
            onEnrollBatch={(b) => {
              if (!enrolledBatches.find(item => item.id === b.id)) {
                setEnrolledBatches([...enrolledBatches, b]);
              }
              showToast(`Enrolled in "${b.title}"!`, "");
              setCurrentView('dashboard');
            }}
          />
        )}

        {currentView === 'how-it-works' && (
          <HowItWorksSection onGetStarted={() => setCurrentView('find-tutors')} />
        )}

        {currentView === 'dashboard' && (
          <DualDashboardView
            role={userRole}
            studentCoins={studentCoins}
            setStudentCoins={setStudentCoins}
            upcomingSessions={upcomingSessions}
            enrolledBatches={enrolledBatches}
            pendingRequests={pendingRequests}
            onAcceptRequest={(r) => {
              setPendingRequests(pendingRequests.filter(item => item.id !== r.id));
              setUpcomingSessions([
                ...upcomingSessions,
                {
                  id: Date.now(),
                  mentorName: "You (Mentor)",
                  college: "IIT Bombay",
                  topic: r.topic,
                  time: r.time,
                  status: "Confirmed"
                }
              ]);
              showToast(`Accepted session with ${r.studentName}!`, "");
            }}
            onDeclineRequest={(r) => {
              setPendingRequests(pendingRequests.filter(item => item.id !== r.id));
              showToast(`Declined request from ${r.studentName}`, "ℹ");
            }}
            onJoinLive={() => setCurrentView('live-room')}
          />
        )}

        {currentView === 'mentor-register' && (
          <LunexaMentorRegistrationWizard
            currentUser={currentUser}
            onComplete={() => {
              showToast("Application submitted! College ID under verification.", "");
              setCurrentView('dashboard');
              setUserRole('mentor');
            }}
            onCancel={() => setCurrentView('landing')}
          />
        )}

        {currentView === 'live-room' && (
          <LiveClassroomMock
            onExit={() => setCurrentView('dashboard')}
            mentor={selectedMentor || MENTORS[2]}
            showToast={showToast}
          />
        )}
      </main>

      {/* 3. FOOTER (Matches Image 2 EXACTLY) */}
      <LunexaFooter
        onNavigate={(view) => setCurrentView(view)}
        onRegisterMentor={() => setCurrentView('mentor-register')}
      />

      {/* 4. MODALS */}
      {activeModal === 'auth' && (
        <LunexaAuthModal
          onClose={() => setActiveModal(null)}
          onSuccess={(userData) => {
            const role = typeof userData === 'object' ? (userData.role || userRole) : userData;
            setUserRole(role);
            if (typeof userData === 'object') {
              setCurrentUser(userData);
              showToast(`Welcome, ${userData.name}!`, "");
            } else {
              setCurrentUser({ name: 'Student', email: 'student@lunexa.edu', role: role });
              showToast(`Logged in successfully!`, "");
            }
            setActiveModal(null);
            setCurrentView('dashboard');
          }}
          onGoToMentorRegistration={(prefill) => {
            setActiveModal(null);
            if (prefill && typeof prefill === 'object') {
              setCurrentUser(prefill);
              showToast(`Google profile connected!`, "");
            }
            setCurrentView('mentor-register');
          }}
        />
      )}

      {activeModal === 'booking' && selectedMentor && (
        <BookingModal
          mentor={selectedMentor}
          onClose={() => setActiveModal(null)}
          onConfirm={(data) => {
            setActiveModal(null);
            setUpcomingSessions([
              ...upcomingSessions,
              {
                id: Date.now(),
                mentorName: selectedMentor.name,
                college: selectedMentor.college,
                topic: data.topic || "Doubt Solving",
                time: `${data.date} at ${data.time}`,
                status: "Confirmed"
              }
            ]);
            showToast(`1:1 Session booked with ${selectedMentor.name}! Check your dashboard.`, "");
            setCurrentView('dashboard');
          }}
        />
      )}

      {activeModal === 'profile' && selectedMentor && (
        <MentorProfileModal
          mentor={selectedMentor}
          onClose={() => setActiveModal(null)}
          onBook={() => setActiveModal('booking')}
        />
      )}

      {/* 5. TOAST NOTIFICATION */}
      {toast && (
        <div className="fixed top-20 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl shadow-2xl bg-slate-900 text-white border border-slate-700 animate-fade-up">
          <span className="text-base">{toast.icon}</span>
          <div className="text-xs font-medium">{toast.message}</div>
          <button onClick={() => setToast(null)} className="text-slate-400 hover:text-white ml-2">
            <Icon name="x" className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 6. AI HELPER CHATBOT (Bottom Right Corner) */}
      <LunexaAIChatbot
        onNavigate={(v) => setCurrentView(v)}
        onOpenAuth={() => setActiveModal('auth')}
      />

    </div>
  );
}

// =========================================================================
// PRICING / FREE TIER PAGE (Matches Image 5 EXACTLY)
// =========================================================================
function LunexaPricingPage({ onStartFree, onFindMentor, onBrowseBatches }) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

      {/* Header Badge & Title */}
      <div className="text-center max-w-2xl mx-auto mb-16">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200/80 dark:border-indigo-800/80 mb-4">
          <span className="text-indigo-500"></span>
          <span>Simple, transparent pricing</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Learning that fits your budget
        </h1>

        <p className="mt-3 text-sm sm:text-base text-slate-500 dark:text-slate-400 leading-relaxed">
          From free volunteer mentoring to structured batch courses. Choose what works for you.
        </p>
      </div>

      {/* 3 Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch max-w-6xl mx-auto">

        {/* CARD 1: Free Starter Trial */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
          <div>
            {/* Top Icon: Green Heart */}
            <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center mb-6 shadow-sm shadow-emerald-500/20">
              <Icon name="heart" className="w-6 h-6 text-white" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Free Starter Trial</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">1 Complimentary Free Live Session</p>

            <div className="my-6">
              <span className="text-4xl font-extrabold text-slate-900 dark:text-white">₹0</span>
              <span className="text-xs text-slate-400 font-medium ml-1">/signup</span>
            </div>

            <button
              onClick={onStartFree}
              className="w-full py-3 rounded-2xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-all shadow-sm mb-8"
            >
              Claim 1 Free Session
            </button>

            {/* Features */}
            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
              {[
                "1 Complimentary Free Live Session",
                "Access to community doubt Q&A",
                "Interactive live classroom demo",
                "Peer practice rooms access",
                "Basic AI study planner",
                "24/7 Community support"
              ].map((f, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <Icon name="check" className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                  <span>{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CARD 2: Token System (Most Popular - Featured) */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border-2 border-[#4F46E5] relative shadow-xl flex flex-col justify-between -mt-2 md:-mt-4">

          {/* Top Most Popular Badge */}
          <div className="absolute -top-3.5 left-1/2 transform -translate-x-1/2 bg-[#4F46E5] text-white text-[11px] font-bold px-3.5 py-1 rounded-full uppercase tracking-wider shadow-md">
             Most Popular
          </div>

          <div>
            {/* Top Icon: Blue Rupee */}
            <div className="w-12 h-12 rounded-2xl bg-[#4F46E5] text-white flex items-center justify-center mb-6 shadow-sm shadow-indigo-500/30">
              <span className="text-xl font-bold font-sans">₹</span>
            </div>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Token System</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Most Popular</p>

            <div className="my-6">
              <span className="text-4xl font-extrabold text-slate-900 dark:text-white">₹150–400</span>
              <span className="text-xs text-slate-400 font-medium ml-1">/per hour</span>
            </div>

            <button
              onClick={onFindMentor}
              className="w-full py-3 rounded-2xl text-xs font-bold text-white bg-[#4F46E5] hover:bg-[#4338CA] shadow-md shadow-indigo-500/25 transition-all mb-8"
            >
              Find a Mentor
            </button>

            {/* Features */}
            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
              {[
                "1 Complimentary Free Live Session included",
                "Access to verified premium mentors",
                "Priority booking & matching",
                "Recorded session replays",
                "Advanced AI study planner",
                "Personalized learning path",
                "Mentor progress tracking"
              ].map((f, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <Icon name="check" className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                  <span>{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CARD 3: Batch Pro */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
          <div>
            {/* Top Icon: Amber Crown */}
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center mb-6 shadow-sm shadow-amber-500/20">
              <Icon name="crown" className="w-6 h-6 text-white" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Batch Pro</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Best for Groups</p>

            <div className="my-6">
              <span className="text-4xl font-extrabold text-slate-900 dark:text-white">₹999+</span>
              <span className="text-xs text-slate-400 font-medium ml-1">/per course</span>
            </div>

            <button
              onClick={onBrowseBatches}
              className="w-full py-3 rounded-2xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-indigo-500 transition-all shadow-sm mb-8"
            >
              Browse Batches
            </button>

            {/* Features */}
            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
              {[
                "All Token features included",
                "Structured batch courses",
                "Curated curriculum",
                "Peer learning community",
                "Certificate of completion",
                "Mentor Q&A priority",
                "Dedicated study groups"
              ].map((f, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <Icon name="check" className="w-4 h-4 text-amber-500 flex-shrink-0" />
                  <span>{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Bottom Note */}
      <div className="text-center text-xs text-slate-400 mt-16 max-w-xl mx-auto">
        All sessions are conducted by verified college students. Free tier is supported by volunteer mentors for SIH social impact.
      </div>

    </div>
  );
}

// =========================================================================
// AUTH MODAL: "CREATE YOUR ACCOUNT" (Matches Image 1 EXACTLY)
// =========================================================================
function LunexaAuthModal({ onClose, onSuccess, onGoToMentorRegistration }) {
  const [role, setRole] = useState('student'); // default to student for quick login
  const [authMode, setAuthMode] = useState('signup'); // 'login' | 'signup'

  // Student form
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  // Initialize and Render Google Sign-In button
  useEffect(() => {
    let interval = null;

    const setupGoogle = () => {
      if (window.google && window.google.accounts && window.google.accounts.id) {
        try {
          window.google.accounts.id.initialize({
            client_id: GOOGLE_CLIENT_ID,
            callback: (response) => {
              setGoogleLoading(false);
              const profile = parseJwt(response.credential);
              if (profile) {
                const userData = {
                  name: profile.name || profile.given_name || 'Google User',
                  email: profile.email,
                  avatar: profile.picture,
                  role: role
                };
                if (role === 'mentor') {
                  onGoToMentorRegistration(userData);
                } else {
                  onSuccess(userData);
                }
              }
            },
            auto_select: false,
            cancel_on_tap_outside: true
          });

          const targetEl = document.getElementById('g-signin-container');
          if (targetEl) {
            targetEl.innerHTML = '';
            window.google.accounts.id.renderButton(targetEl, {
              theme: 'outline',
              size: 'large',
              width: 340,
              text: authMode === 'signup' ? 'signup_with' : 'signin_with',
              shape: 'pill',
              logo_alignment: 'left'
            });
          }

          if (interval) clearInterval(interval);
        } catch (e) {
          console.warn("Google Sign-In initialization notice:", e);
        }
      }
    };

    setupGoogle();
    interval = setInterval(setupGoogle, 400);
    const timeout = setTimeout(() => {
      if (interval) clearInterval(interval);
    }, 4000);

    return () => {
      if (interval) clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [authMode, role]);

  const handleGooglePrompt = () => {
    if (window.google && window.google.accounts && window.google.accounts.id) {
      setGoogleLoading(true);
      window.google.accounts.id.prompt((notification) => {
        if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
          setGoogleLoading(false);
        }
      });
    } else {
      alert("Google Sign-In service is loading... If running locally, ensure third-party cookies or scripts are allowed.");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email.includes('@') || password.length < 4) {
      alert("Please enter a valid email and password.");
      return;
    }
    onSuccess({
      name: name || (role === 'student' ? 'Kavya Mehra' : 'Mentor'),
      email: email,
      role: role
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-7 max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl relative animate-fade-up">

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
        >
          <Icon name="x" className="w-5 h-5" />
        </button>

        {/* Top Icon: Lunexa Logo */}
        <div className="flex items-center justify-center mx-auto mb-4">
          <img
            src="logo-light.png"
            alt="Lunexa"
            className="dark:hidden h-12 w-auto object-contain rounded-xl"
          />
          <img
            src="logo-full.png"
            alt="Lunexa"
            className="hidden dark:block h-12 w-auto object-contain rounded-xl"
          />
        </div>

        {/* Title & Subtitle */}
        <div className="text-center mb-5">
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            {authMode === 'signup' ? 'Create Your Account' : 'Welcome Back'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Join Lunexa smart digital peer learning
          </p>
        </div>

        {/* Role Segmented Control Toggle */}
        <div className="flex p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold mb-4">
          <button
            type="button"
            onClick={() => setRole('student')}
            className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all ${role === 'student'
              ? 'bg-white dark:bg-slate-700 text-[#4F46E5] dark:text-indigo-400 shadow-sm font-bold'
              : 'text-slate-500 dark:text-slate-400'
              }`}
          >
            <Icon name="book-open" className="w-4 h-4" />
            <span>I am a Student</span>
          </button>

          <button
            type="button"
            onClick={() => setRole('mentor')}
            className={`flex-1 py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all ${role === 'mentor'
              ? 'bg-white dark:bg-slate-700 text-[#4F46E5] dark:text-indigo-400 shadow-sm font-bold'
              : 'text-slate-500 dark:text-slate-400'
              }`}
          >
            <Icon name="users" className="w-4 h-4" />
            <span>I am a Teacher</span>
          </button>
        </div>

        {/* Sub-toggle: Log In | Sign Up */}
        <div className="flex items-center justify-between text-xs mb-4 px-1">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setAuthMode('login')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${authMode === 'login'
                ? 'bg-indigo-50 dark:bg-indigo-950/60 text-[#4F46E5] dark:text-indigo-400'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
            >
              Log In
            </button>
            <span className="text-slate-300">|</span>
            <button
              type="button"
              onClick={() => setAuthMode('signup')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${authMode === 'signup'
                ? 'bg-indigo-50 dark:bg-indigo-950/60 text-[#4F46E5] dark:text-indigo-400'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
            >
              Sign Up
            </button>
          </div>
          <span className="text-[11px] text-slate-400 font-medium">Fast 1-Click Login</span>
        </div>

        {/* GOOGLE SIGN-IN SECTION */}
        <div className="mb-4">
          {/* Target for Google Identity Services Button */}
          <div id="g-signin-container" className="w-full flex justify-center min-h-[44px]">
            {/* Direct fallback trigger button */}
            <button
              type="button"
              onClick={handleGooglePrompt}
              disabled={googleLoading}
              className="w-full py-2.5 px-4 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-semibold shadow-sm hover:shadow flex items-center justify-center gap-3 transition-all"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>{googleLoading ? 'Connecting to Google...' : (authMode === 'signup' ? `Sign up as ${role === 'student' ? 'Student' : 'Teacher'}` : `Sign in as ${role === 'student' ? 'Student' : 'Teacher'}`)}</span>
            </button>
          </div>

          <div className="flex items-center my-3.5">
            <div className="flex-1 border-t border-slate-200 dark:border-slate-800"></div>
            <span className="px-3 text-[10px] text-slate-400 uppercase font-semibold tracking-wider">or with email</span>
            <div className="flex-1 border-t border-slate-200 dark:border-slate-800"></div>
          </div>
        </div>

        {/* AUTH FORM FOR BOTH STUDENTS & TEACHERS */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {authMode === 'signup' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Full Name
              </label>
              <input
                type="text"
                placeholder={role === 'student' ? "e.g. Kavya Mehra" : "e.g. Prof. Rahul Sharma"}
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Email Address
            </label>
            <input
              type="email"
              placeholder={role === 'student' ? "student@example.com" : "teacher@college.edu"}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password (min 6 chars)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-2.5 pr-10 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400"
              >
                <Icon name={showPassword ? "eye-off" : "eye"} className="w-4 h-4" />
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl font-semibold text-xs text-white bg-[#4F46E5] hover:bg-[#4338CA] shadow-sm transition-all"
          >
            {authMode === 'signup'
              ? (role === 'student' ? 'Create Student Account' : 'Create Teacher Account')
              : (role === 'student' ? 'Log In as Student' : 'Log In as Teacher')}
          </button>
        </form>

        {role === 'mentor' && (
          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => onGoToMentorRegistration()}
              className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
            >
              Need formal institutional verification? Complete Full Onboarding Wizard →
            </button>
          </div>
        )}

      </div>
    </div>
  );
}

// =========================================================================
// MENTOR REGISTRATION 3-STEP WIZARD (Matches Images 3 & 4 EXACTLY)
// =========================================================================
function LunexaMentorRegistrationWizard({ onComplete, onCancel, currentUser }) {
  const [step, setStep] = useState(1); // 1, 2, 3

  // Step 1 Form Fields
  const [fullName, setFullName] = useState(currentUser?.name || 'Rahul Sharma');
  const [email, setEmail] = useState(currentUser?.email || 'college.email@iitb.ac.in');
  const [phone, setPhone] = useState('+91 98765 43210');
  const [college, setCollege] = useState('IIT Bombay');
  const [rollNumber, setRollNumber] = useState('2024CSE102');
  const [idFileUploaded, setIdFileUploaded] = useState(false);
  const [yearOfStudy, setYearOfStudy] = useState('Select year');

  // Step 2 Form Fields
  const [subjects, setSubjects] = useState(['JEE Maths', 'Physics']);
  const [languages, setLanguages] = useState(['English', 'Hindi']);
  const [bio, setBio] = useState('AIR 450 in JEE Advanced. Passionate about teaching calculus and mechanics.');
  const [videoUrl, setVideoUrl] = useState('');
  const [experience, setExperience] = useState('1-3 Years');

  // Step 3 Form Fields
  const [teachingModes, setTeachingModes] = useState(['1:1 Live Mentorship']);
  const [availability, setAvailability] = useState(['Mon-Fri Evening']);
  const [rateType, setRateType] = useState('paid');
  const [agreedTerms, setAgreedTerms] = useState(false);

  const handleNext = () => {
    if (step === 1) {
      if (!fullName.trim() || !email.includes('@') || !rollNumber.trim()) {
        alert("Please fill all required fields.");
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (subjects.length === 0) {
        alert("Select at least one subject.");
        return;
      }
      setStep(3);
    } else if (step === 3) {
      if (!agreedTerms) {
        alert("Please agree to the credentials verification terms.");
        return;
      }
      onComplete();
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">

      {/* Top Header with Graduation Cap Icon (Matches Image 4) */}
      <div className="text-center mb-8">
        <div className="w-12 h-12 rounded-2xl bg-[#4F46E5] text-white flex items-center justify-center mx-auto mb-3 shadow-md shadow-indigo-500/25">
          <Icon name="graduation-cap" className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
          Mentor Registration
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Join 500+ verified college mentors on Lunexa
        </p>
      </div>

      {/* Stepper Header (Matches Image 4) */}
      <div className="flex items-center justify-between max-w-lg mx-auto mb-10 relative">
        {/* Step 1 */}
        <div className="flex flex-col items-center z-10">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white transition-all ${step >= 1 ? 'bg-[#4F46E5]' : 'bg-slate-200 text-slate-400'
            }`}>
            <Icon name="shield" className="w-5 h-5 text-white" />
          </div>
          <span className={`text-xs mt-2 font-medium ${step === 1 ? 'text-[#4F46E5] font-bold' : 'text-slate-400'}`}>
            Personal & College
          </span>
        </div>

        {/* Connecting Line 1 */}
        <div className={`flex-1 h-0.5 mx-2 -mt-6 rounded transition-colors ${step >= 2 ? 'bg-[#4F46E5]' : 'bg-slate-200 dark:bg-slate-700'}`}></div>

        {/* Step 2 */}
        <div className="flex flex-col items-center z-10">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${step >= 2 ? 'bg-[#4F46E5] text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
            }`}>
            <Icon name="book-open" className="w-5 h-5" />
          </div>
          <span className={`text-xs mt-2 font-medium ${step === 2 ? 'text-[#4F46E5] font-bold' : 'text-slate-400'}`}>
            Teaching Expertise
          </span>
        </div>

        {/* Connecting Line 2 */}
        <div className={`flex-1 h-0.5 mx-2 -mt-6 rounded transition-colors ${step >= 3 ? 'bg-[#4F46E5]' : 'bg-slate-200 dark:bg-slate-700'}`}></div>

        {/* Step 3 */}
        <div className="flex flex-col items-center z-10">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${step >= 3 ? 'bg-[#4F46E5] text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
            }`}>
            <Icon name="calendar" className="w-5 h-5" />
          </div>
          <span className={`text-xs mt-2 font-medium ${step === 3 ? 'text-[#4F46E5] font-bold' : 'text-slate-400'}`}>
            Availability & Mode
          </span>
        </div>
      </div>

      {/* Main Form Container (Matches Images 3 & 4) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-10 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">

        {/* STEP 1: PERSONAL & COLLEGE VERIFICATION */}
        {step === 1 && (
          <div className="space-y-5">
            {/* Step 1 Title */}
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <Icon name="shield" className="w-5 h-5 text-[#4F46E5]" />
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                Personal & College Verification
              </h2>
            </div>

            {/* Full Name */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                <Icon name="user" className="w-3.5 h-3.5 text-slate-400" />
                <span>Full Name</span>
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g., Rahul Sharma"
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Email Address */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                <Icon name="mail" className="w-3.5 h-3.5 text-slate-400" />
                <span>Email Address</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="college.email@iitb.ac.in"
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Phone Number */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                <Icon name="phone" className="w-3.5 h-3.5 text-slate-400" />
                <span>Phone Number</span>
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* College / University Name */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                <Icon name="search" className="w-3.5 h-3.5 text-slate-400" />
                <span>College / University Name</span>
              </label>
              <select
                value={college}
                onChange={(e) => setCollege(e.target.value)}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="IIT Bombay">IIT Bombay</option>
                <option value="IIT Delhi">IIT Delhi</option>
                <option value="IIT Madras">IIT Madras</option>
                <option value="BITS Pilani">BITS Pilani</option>
                <option value="NIT Trichy">NIT Trichy</option>
                <option value="Delhi University">Delhi University</option>
                <option value="AIIMS New Delhi">AIIMS New Delhi</option>
                <option value="S-VYASA Bangalore">S-VYASA Bangalore</option>
                <option value="Other Premier College">Other Accredited College</option>
              </select>
            </div>

            {/* Student Roll / ID Number */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                <Icon name="file-text" className="w-3.5 h-3.5 text-slate-400" />
                <span>Student Roll / ID Number</span>
              </label>
              <input
                type="text"
                value={rollNumber}
                onChange={(e) => setRollNumber(e.target.value)}
                placeholder="e.g., 2024CSE102"
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Upload Student ID Card (Matches Image 3) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Upload Student ID Card
              </label>
              <div
                onClick={() => setIdFileUploaded(true)}
                className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${idFileUploaded
                  ? 'border-emerald-500 bg-emerald-50/40 dark:bg-emerald-950/20'
                  : 'border-indigo-400 bg-indigo-50/20 dark:bg-indigo-950/10 hover:bg-indigo-50/40'
                  }`}
              >
                {idFileUploaded ? (
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center mb-2">
                      <Icon name="check" className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-xs font-bold text-emerald-600">
                      student_id_card.pdf uploaded successfully!
                    </span>
                    <span className="text-[10px] text-slate-400 mt-0.5">Click to change file</span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <Icon name="camera" className="w-8 h-8 text-slate-400 mb-2" />
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      Drag & drop or click to upload
                    </span>
                    <span className="text-[11px] text-slate-400 mt-0.5">
                      JPG, PNG, or PDF (max 5MB)
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Current Year of Study (Matches Image 3) */}
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                <Icon name="graduation-cap" className="w-3.5 h-3.5 text-slate-400" />
                <span>Current Year of Study</span>
              </label>
              <select
                value={yearOfStudy}
                onChange={(e) => setYearOfStudy(e.target.value)}
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Select year">Select year</option>
                <option value="1st Year">1st Year Undergrad</option>
                <option value="2nd Year">2nd Year Undergrad</option>
                <option value="3rd Year">3rd Year Undergrad</option>
                <option value="4th Year">4th Year Undergrad</option>
                <option value="PostGrad">Postgraduate / Masters</option>
              </select>
            </div>

            {/* Next Step Button (Matches Image 3) */}
            <div className="pt-4 flex justify-end">
              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl font-semibold text-xs text-white bg-[#4F46E5] hover:bg-[#4338CA] shadow-sm flex items-center gap-2"
              >
                <span>Next Step</span>
                <Icon name="arrow-right" className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: TEACHING EXPERTISE & BIO */}
        {step === 2 && (
          <div className="space-y-5">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <Icon name="book-open" className="w-5 h-5 text-[#4F46E5]" />
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                Teaching Expertise & Bio
              </h2>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Primary Subject Expertise
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  'Physics',
                  'JEE Maths',
                  'Data Structures & Algo',
                  'Web Dev',
                  'Organic Chemistry',
                  'English'
                ].map(sub => {
                  const active = subjects.includes(sub);
                  return (
                    <button
                      key={sub}
                      type="button"
                      onClick={() => {
                        if (active) setSubjects(subjects.filter(s => s !== sub));
                        else setSubjects([...subjects, sub]);
                      }}
                      className={`p-2.5 rounded-xl border text-xs text-left flex items-center justify-between transition-all ${active
                        ? 'border-[#4F46E5] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                        }`}
                    >
                      <span>{sub}</span>
                      {active && <Icon name="check" className="w-3.5 h-3.5 text-indigo-600" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Languages Spoken
              </label>
              <div className="flex flex-wrap gap-2">
                {['English', 'Hindi', 'Hinglish', 'Regional'].map(l => {
                  const active = languages.includes(l);
                  return (
                    <button
                      key={l}
                      type="button"
                      onClick={() => {
                        if (active) setLanguages(languages.filter(item => item !== l));
                        else setLanguages([...languages, l]);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border ${active
                        ? 'bg-[#4F46E5] text-white border-[#4F46E5]'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                    >
                      {l}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Short Bio
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Briefly describe your achievement, e.g., AIR 450 in JEE Advanced, love teaching Calculus..."
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Demo Video URL
              </label>
              <input
                type="url"
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                placeholder="YouTube or Drive link of a 2-min sample teaching video"
                className="w-full p-2.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Prior Teaching Experience
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {['No Experience', '< 1 Year', '1-3 Years', '3+ Years'].map(exp => (
                  <button
                    key={exp}
                    type="button"
                    onClick={() => setExperience(exp)}
                    className={`py-2 px-3 text-xs font-semibold rounded-xl border text-center ${experience === exp
                      ? 'border-[#4F46E5] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 font-bold'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600'
                      }`}
                  >
                    {exp}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 flex justify-between">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
              >
                ← Previous Step
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl font-semibold text-xs text-white bg-[#4F46E5] hover:bg-[#4338CA] shadow-sm flex items-center gap-2"
              >
                <span>Next Step</span>
                <Icon name="arrow-right" className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: AVAILABILITY & MODE */}
        {step === 3 && (
          <div className="space-y-5">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <Icon name="calendar" className="w-5 h-5 text-[#4F46E5]" />
              <h2 className="font-bold text-base text-slate-900 dark:text-white">
                Availability & Mode
              </h2>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Preferred Teaching Mode
              </label>
              <div className="grid grid-cols-2 gap-3">
                {['1:1 Live Mentorship', 'Batch Classes'].map(m => {
                  const active = teachingModes.includes(m);
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() => {
                        if (active) setTeachingModes(teachingModes.filter(item => item !== m));
                        else setTeachingModes([...teachingModes, m]);
                      }}
                      className={`p-3 rounded-xl border text-xs text-left font-semibold flex items-center justify-between ${active
                        ? 'border-[#4F46E5] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                        }`}
                    >
                      <span>{m}</span>
                      {active && <Icon name="check" className="w-4 h-4 text-indigo-600" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Weekly Availability
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {['Mon-Fri Evening', 'Saturday Full Day', 'Sunday Morning'].map(s => {
                  const active = availability.includes(s);
                  return (
                    <button
                      key={s}
                      type="button"
                      onClick={() => {
                        if (active) setAvailability(availability.filter(item => item !== s));
                        else setAvailability([...availability, s]);
                      }}
                      className={`p-2.5 rounded-xl border text-xs text-left font-semibold flex items-center justify-between ${active
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                        }`}
                    >
                      <span>{s}</span>
                      {active && <Icon name="check" className="w-3.5 h-3.5 text-emerald-600" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Class Rates / Volunteering
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  onClick={() => setRateType('free')}
                  className={`p-3.5 rounded-2xl border cursor-pointer ${rateType === 'free' ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-200 dark:border-slate-700'
                    }`}
                >
                  <div className="text-xs font-bold text-emerald-700">Free / Volunteer for SIH Impact</div>
                  <p className="text-[11px] text-slate-500 mt-1">Volunteer certificates and community credits.</p>
                </div>

                <div
                  onClick={() => setRateType('paid')}
                  className={`p-3.5 rounded-2xl border cursor-pointer ${rateType === 'paid' ? 'border-[#4F46E5] bg-indigo-50/50' : 'border-slate-200 dark:border-slate-700'
                    }`}
                >
                  <div className="text-xs font-bold text-[#4F46E5]">Paid Token System (e.g., ₹150 - ₹400 / hour)</div>
                  <p className="text-[11px] text-slate-500 mt-1">Earn direct honorarium payouts via UPI.</p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={agreedTerms}
                  onChange={(e) => setAgreedTerms(e.target.checked)}
                  className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-slate-600 dark:text-slate-300 font-medium">
                  I agree that my college credentials can be verified.
                </span>
              </label>
            </div>

            <div className="pt-4 flex justify-between">
              <button
                onClick={() => setStep(2)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
              >
                ← Previous Step
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl font-semibold text-xs text-white bg-[#4F46E5] hover:bg-[#4338CA] shadow-sm"
              >
                Submit Mentor Application
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

// =========================================================================
// FOOTER (Matches Image 2 EXACTLY)
// =========================================================================
function LunexaFooter({ onNavigate, onRegisterMentor }) {
  return (
    <footer className="bg-[#0B0F19] text-white pt-14 pb-8 border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-10">

          {/* Left Column: Brand, Tagline, SIH Badge */}
          <div className="md:col-span-4 space-y-3">
            <div className="flex items-center cursor-pointer" onClick={() => onNavigate('landing')}>
              <img
                src="logo-full.png"
                alt="Lunexa"
                className="h-10 w-auto rounded-lg object-contain shadow-sm"
              />
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              P2P smart digital learning connecting school students with verified college mentors.
            </p>

            {/* Verified Network Badge */}
            <div className="pt-1">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/40">
                <span></span>
                <span>Verified Peer Network</span>
              </span>
            </div>
          </div>

          {/* Column 2: Platform */}
          <div className="md:col-span-3 space-y-2.5 text-xs">
            <h4 className="font-semibold text-white text-sm mb-3">Platform</h4>
            <div>
              <button onClick={() => onNavigate('find-tutors')} className="text-slate-400 hover:text-white transition-colors">
                Find Tutors
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('batches')} className="text-slate-400 hover:text-white transition-colors">
                Batch Classes
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('how-it-works')} className="text-slate-400 hover:text-white transition-colors">
                How It Works
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('pricing')} className="text-slate-400 hover:text-white transition-colors">
                Pricing
              </button>
            </div>
          </div>

          {/* Column 3: For Mentors */}
          <div className="md:col-span-3 space-y-2.5 text-xs">
            <h4 className="font-semibold text-white text-sm mb-3">For Mentors</h4>
            <div>
              <button onClick={onRegisterMentor} className="text-slate-400 hover:text-white transition-colors">
                Become a Mentor
              </button>
            </div>
            <div>
              <button onClick={() => alert("Mentor guidelines: Maintain verified institutional credentials and uphold academic integrity.")} className="text-slate-400 hover:text-white transition-colors">
                Mentor Guidelines
              </button>
            </div>
            <div>
              <button onClick={() => onNavigate('pricing')} className="text-slate-400 hover:text-white transition-colors">
                Earnings
              </button>
            </div>
          </div>

          {/* Column 4: Connect */}
          <div className="md:col-span-2 space-y-2.5 text-xs">
            <h4 className="font-semibold text-white text-sm mb-3">Connect</h4>
            <a href="mailto:lunexaedu@gmail.com" className="text-slate-400 hover:text-indigo-400 transition-colors block">lunexaedu@gmail.com</a>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <div>
            © 2026 Lunexa. All rights reserved.
          </div>
          <div className="flex items-center gap-1 text-slate-400">
            <span>Built with</span>
            <span className="text-rose-500"></span>
            <span>for Smart Education</span>
          </div>
        </div>

      </div>
    </footer>
  );
}

// =========================================================================
// INTERACTIVE LIVE CLASSROOM PREVIEW COMPONENT
// =========================================================================
function LiveClassroomPreviewCard({ onOpenLiveRoom }) {
  const [messages, setMessages] = useState([
    { id: 1, sender: 'You', role: 'student', text: 'Can you explain integration by parts again?', time: '10:42 AM' },
    { id: 2, sender: 'Rahul Sharma (IIT Bombay)', role: 'mentor', text: "Sure! Remember: ∫ u dv = uv - ∫ v du. Always choose 'u' using the ILATE rule.", time: '10:43 AM' },
    { id: 3, sender: 'Kavya M.', role: 'student', text: 'That makes so much sense now! Thank you Rahul bhai!', time: '10:43 AM' }
  ]);
  const [inputMsg, setInputMsg] = useState('');
  const [handRaised, setHandRaised] = useState(false);
  const [micActive, setMicActive] = useState(false);
  const [activeTool, setActiveTool] = useState('laser');
  const [activeTab, setActiveTab] = useState('whiteboard');
  const chatEndRef = useRef(null);

  const handleSend = (textToSend) => {
    const query = (typeof textToSend === 'string' ? textToSend : inputMsg).trim();
    if (!query) return;

    const newMsg = {
      id: Date.now(),
      sender: 'You',
      role: 'student',
      text: query,
      time: 'Just now'
    };

    setMessages(prev => [...prev, newMsg]);
    setInputMsg('');

    setTimeout(() => {
      let replyText = "Great question! Let me write down the step on the board.";
      const lower = query.toLowerCase();
      if (lower.includes('ilate')) {
        replyText = "ILATE priority: Inverse > Logarithmic > Algebraic > Trigonometric > Exponential!";
      } else if (lower.includes('limit') || lower.includes('definite')) {
        replyText = "For definite integrals: evaluate [uv] from a to b, then subtract ∫ v du over [a,b].";
      } else if (lower.includes('step 2') || lower.includes('again') || lower.includes('clear')) {
        replyText = "Step 2: Differentiate u to get du, integrate dv to get v, then plug into uv - ∫v du!";
      }

      setMessages(prev => [
        ...prev,
        {
          id: Date.now() + 1,
          sender: 'Rahul Sharma (IIT Bombay)',
          role: 'mentor',
          text: replyText,
          time: 'Just now'
        }
      ]);
    }, 800);
  };

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  return (
    <div className="mt-14 max-w-5xl mx-auto bg-slate-900 text-slate-100 rounded-3xl border border-indigo-500/30 shadow-2xl shadow-indigo-950/50 relative overflow-hidden text-left ring-1 ring-white/10">
      
      {/* Studio Header Bar */}
      <div className="px-5 py-3.5 bg-slate-950/95 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Window Controls + Live Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-500 inline-block shadow-sm"></span>
            <span className="w-3 h-3 rounded-full bg-amber-500 inline-block shadow-sm"></span>
            <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block shadow-sm"></span>
          </div>

          <div className="h-4 w-px bg-slate-800 hidden sm:block"></div>

          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 text-[10px] font-extrabold tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping"></span>
              LIVE STUDIO
            </span>
            <span className="text-xs text-slate-200 font-semibold hidden md:inline">
              Advanced Calculus • JEE 2026 Batch
            </span>
          </div>
        </div>

        {/* Right: Latency info + Enter button */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-400 font-mono">
            <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> 1080p 60fps
            </span>
            <span>•</span>
            <span>12ms ping</span>
            <span>•</span>
            <span className="text-indigo-300 font-medium"> 38 Students</span>
          </div>

          <button
            type="button"
            onClick={onOpenLiveRoom}
            className="px-4 py-1.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 shadow-md shadow-indigo-600/30 flex items-center gap-1.5 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
          >
            <Icon name="video" className="w-3.5 h-3.5" />
            <span>Enter Classroom</span>
          </button>
        </div>
      </div>

      {/* Main Studio Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 items-stretch">

        {/* Left: Collaborative Interactive Whiteboard (7 cols) */}
        <div className="lg:col-span-7 bg-[#060814] p-4 sm:p-5 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-800/80 relative min-h-[390px]">
          
          {/* Top Canvas Bar */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 gap-2">
            <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setActiveTab('whiteboard')}
                className={`px-3 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                  activeTab === 'whiteboard'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                 Whiteboard
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('graph')}
                className={`px-3 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                  activeTab === 'graph'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                 Graph Curve
              </button>
            </div>

            {/* Whiteboard Tool Palette */}
            <div className="flex items-center gap-1 bg-slate-900/90 px-2 py-1 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setActiveTool('pen')}
                title="Pen tool"
                className={`p-1.5 rounded-lg text-xs transition-all ${activeTool === 'pen' ? 'bg-indigo-600/40 text-indigo-300 ring-1 ring-indigo-400' : 'text-slate-400 hover:text-slate-200'}`}
              >
                <Icon name="pen-tool" className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setActiveTool('eraser')}
                title="Eraser tool"
                className={`p-1.5 rounded-lg text-xs transition-all ${activeTool === 'eraser' ? 'bg-indigo-600/40 text-indigo-300 ring-1 ring-indigo-400' : 'text-slate-400 hover:text-slate-200'}`}
              >
                <Icon name="eraser" className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setActiveTool('laser')}
                title="Laser pointer"
                className={`p-1.5 rounded-lg text-xs transition-all ${activeTool === 'laser' ? 'bg-rose-600/40 text-rose-300 ring-1 ring-rose-400' : 'text-slate-400 hover:text-slate-200'}`}
              >
                
              </button>
            </div>
          </div>

          {/* Canvas Center View */}
          <div className="my-auto py-5 relative">
            
            {/* Subtle Grid Dot Background */}
            <div
              className="absolute inset-0 opacity-20 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(#6366f1 1.2px, transparent 1.2px)',
                backgroundSize: '20px 20px'
              }}
            ></div>

            {/* Mentor Live Video Overlay in Canvas Top-Right */}
            <div className="absolute top-1 right-1 z-10 bg-slate-900/90 backdrop-blur-md rounded-2xl p-2 border border-slate-700/80 shadow-xl flex items-center gap-2.5">
              <div className="relative">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white font-bold text-xs flex items-center justify-center shadow">
                  RS
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-900 flex items-center justify-center">
                  <span className="w-1 h-1 rounded-full bg-white animate-ping"></span>
                </span>
              </div>
              <div className="pr-1 text-left">
                <div className="flex items-center gap-1">
                  <span className="font-bold text-[11px] text-white">Rahul Sharma</span>
                  <span className="px-1 py-0.2 rounded bg-indigo-500/30 text-indigo-300 text-[9px] font-semibold">IIT Bombay</span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-400">
                  <span className="flex items-end gap-0.5 h-2.5">
                    <span className="w-0.5 h-1.5 bg-emerald-400 animate-pulse"></span>
                    <span className="w-0.5 h-2.5 bg-emerald-400 animate-pulse"></span>
                    <span className="w-0.5 h-2 bg-emerald-400 animate-pulse"></span>
                  </span>
                  <span>Audio Live</span>
                </div>
              </div>
            </div>

            {activeTab === 'whiteboard' ? (
              <div className="text-center font-mono relative z-0 pt-4">
                {/* Main Color-Coded Derived Formula */}
                <div className="inline-block p-3 sm:p-4 rounded-2xl bg-slate-900/85 border border-indigo-500/40 backdrop-blur-md shadow-2xl">
                  <div className="text-xl sm:text-3xl font-extrabold text-white tracking-wider flex items-center justify-center flex-wrap gap-2">
                    <span className="text-indigo-400 text-3xl font-serif">∫</span>
                    <span className="text-cyan-300 font-bold bg-cyan-500/15 px-2 py-0.5 rounded-lg border border-cyan-500/40 shadow-sm">u</span>
                    <span className="text-indigo-300 font-bold bg-indigo-500/15 px-2 py-0.5 rounded-lg border border-indigo-500/40 shadow-sm">dv</span>
                    <span className="text-slate-400 font-sans">=</span>
                    <span className="text-emerald-300 font-bold bg-emerald-500/15 px-2 py-0.5 rounded-lg border border-emerald-500/40 shadow-sm">uv</span>
                    <span className="text-slate-400 font-sans">-</span>
                    <span className="text-indigo-400 text-3xl font-serif">∫</span>
                    <span className="text-amber-300 font-bold bg-amber-500/15 px-2 py-0.5 rounded-lg border border-amber-500/40 shadow-sm">v</span>
                    <span className="text-cyan-300 font-bold bg-cyan-500/15 px-2 py-0.5 rounded-lg border border-cyan-500/40 shadow-sm">du</span>
                  </div>
                </div>

                {/* Subtitle formula breakdown steps */}
                <div className="mt-4 max-w-md mx-auto space-y-2 text-left bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 text-[11px]">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-cyan-400 font-semibold">1. Choose u:</span>
                    <span className="text-slate-400 font-sans">Apply <strong className="text-amber-300">ILATE</strong> (Inverse, Log, Alg, Trig, Exp)</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-emerald-400 font-semibold">2. Differentiate u:</span>
                    <span className="text-slate-400 font-mono">du = u'(x) dx</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-amber-400 font-semibold">3. Integrate dv:</span>
                    <span className="text-slate-400 font-mono">v = ∫ dv = v(x)</span>
                  </div>
                </div>

                {/* Animated Laser Pointer */}
                {activeTool === 'laser' && (
                  <div className="absolute -bottom-1 left-1/4 flex items-center gap-1.5 pointer-events-none animate-pulse">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_12px_#f43f5e]"></span>
                    <span className="text-[10px] font-sans px-2 py-0.5 rounded bg-rose-950/90 text-rose-300 border border-rose-800/80 shadow-md">
                      Rahul is pointing here
                    </span>
                  </div>
                )}
              </div>
            ) : (
              /* Graph View Tab */
              <div className="py-2 flex flex-col items-center">
                <svg className="w-full max-w-sm h-40" viewBox="0 0 320 160">
                  {/* Grid Lines */}
                  <line x1="20" y1="140" x2="300" y2="140" stroke="#334155" strokeWidth="1.5" />
                  <line x1="40" y1="10" x2="40" y2="150" stroke="#334155" strokeWidth="1.5" />
                  
                  {/* Shaded Area Under Curve */}
                  <path
                    d="M 60 140 Q 130 30 200 80 L 200 140 Z"
                    fill="url(#indigoGradPreview)"
                    opacity="0.35"
                  />
                  
                  {/* Curve y = f(x) */}
                  <path
                    d="M 40 140 Q 130 20 280 110"
                    fill="none"
                    stroke="#818CF8"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />

                  {/* Laser point on curve */}
                  <circle cx="140" cy="50" r="5" fill="#EF4444" className="animate-pulse" />
                  <circle cx="140" cy="50" r="10" fill="none" stroke="#EF4444" opacity="0.6" />
                  
                  {/* Labels */}
                  <text x="290" y="135" fill="#94A3B8" fontSize="10" fontFamily="sans-serif">x</text>
                  <text x="25" y="20" fill="#94A3B8" fontSize="10" fontFamily="sans-serif">y</text>
                  <text x="145" y="45" fill="#F87171" fontSize="10" fontFamily="monospace">P(x, y)</text>
                  <text x="100" y="115" fill="#A5B4FC" fontSize="11" fontWeight="bold" fontFamily="monospace">Area = ∫ f(x)dx</text>

                  <defs>
                    <linearGradient id="indigoGradPreview" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#6366F1" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#6366F1" stopOpacity="0.05" />
                    </linearGradient>
                  </defs>
                </svg>
                <span className="text-[11px] text-slate-400 mt-1 font-mono">Geometric proof: Area under curve between limits [a, b]</span>
              </div>
            )}

          </div>

          {/* Bottom Interactive Controls */}
          <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span className="text-slate-300 text-[11px]">
                Active student: <strong className="text-white font-medium">Kavya M. (CBSE 12)</strong>
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Interactive Hand Raise Button */}
              <button
                type="button"
                onClick={() => setHandRaised(!handRaised)}
                className={`px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1.5 transition-all ${
                  handRaised
                    ? 'bg-amber-500/25 text-amber-300 border border-amber-500/60 shadow-md shadow-amber-500/20'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                }`}
              >
                <span></span>
                <span>{handRaised ? 'Hand Raised (#1 in line)' : 'Raise Hand'}</span>
              </button>

              {/* Interactive Mic Toggle */}
              <button
                type="button"
                onClick={() => setMicActive(!micActive)}
                className={`p-1.5 rounded-xl border text-xs transition-all ${
                  micActive
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                }`}
                title={micActive ? 'Mic Active' : 'Mic Muted'}
              >
                <Icon name={micActive ? 'mic' : 'mic-off'} className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* Right: Interactive Real-Time Classroom Chat (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950/70 p-4 sm:p-5 flex flex-col justify-between text-xs">
          
          {/* Chat Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-200">Live Classroom Chat</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-semibold">
                 Active
              </span>
            </div>
            <span className="text-[10px] text-slate-500">Auto-moderated</span>
          </div>

          {/* Chat Messages Stream */}
          <div className="space-y-2.5 flex-1 mb-3 overflow-y-auto max-h-[220px] pr-1">
            {messages.map((m) => {
              const isMe = m.role === 'student' && m.sender === 'You';
              const isMentor = m.role === 'mentor';
              return (
                <div
                  key={m.id}
                  className={`p-2.5 rounded-2xl transition-all ${
                    isMentor
                      ? 'bg-gradient-to-r from-indigo-950/80 to-violet-950/80 border border-indigo-500/40 text-indigo-50 shadow-sm'
                      : isMe
                      ? 'bg-indigo-600 text-white ml-4 shadow-sm'
                      : 'bg-slate-900/90 border border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="font-bold flex items-center gap-1">
                      {isMentor && <span></span>}
                      {m.sender}
                    </span>
                    <span className={isMe ? 'text-indigo-200' : 'text-slate-400'}>{m.time}</span>
                  </div>
                  <p className="text-xs leading-relaxed">{m.text}</p>
                </div>
              );
            })}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Suggestion Pills */}
          <div className="flex items-center gap-1.5 mb-2.5 overflow-x-auto pb-1 text-[11px]">
            <button
              type="button"
              onClick={() => handleSend("Can you review the ILATE rule again?")}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 whitespace-nowrap transition-colors"
            >
               ILATE Rule?
            </button>
            <button
              type="button"
              onClick={() => handleSend("What about definite integral limits?")}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 whitespace-nowrap transition-colors"
            >
               Definite Limits?
            </button>
            <button
              type="button"
              onClick={() => handleSend("That makes complete sense, thanks sir!")}
              className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 whitespace-nowrap transition-colors"
            >
               Crystal clear!
            </button>
          </div>

          {/* Interactive Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMsg}
              onChange={(e) => setInputMsg(e.target.value)}
              placeholder="Ask Rahul a doubt in real-time..."
              className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-800 bg-slate-900/90 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all flex items-center justify-center"
              title="Send doubt"
            >
              <Icon name="send" className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>

      </div>

    </div>
  );
}

// =========================================================================
// AI HELPER CHATBOT WIDGET (Bottom Right Corner)
// =========================================================================
function LunexaAIChatbot({ onNavigate, onOpenAuth }) {
  const [isOpen, setIsOpen] = useState(false);
  const [apiKey, setApiKey] = useState(localStorage.getItem('lunexa_gemini_api_key') || '');
  const [showKeyInput, setShowKeyInput] = useState(false);
  const [inputMsg, setInputMsg] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'bot',
      text: "Hi!  I'm Lunexa AI, your 24/7 learning & platform assistant! How can I help you today?",
      time: 'Just now'
    }
  ]);

  const chatEndRef = useRef(null);

  useEffect(() => {
    if (isOpen && chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSaveApiKey = (key) => {
    const trimmed = key.trim();
    setApiKey(trimmed);
    if (trimmed) {
      localStorage.setItem('lunexa_gemini_api_key', trimmed);
    } else {
      localStorage.removeItem('lunexa_gemini_api_key');
    }
    setShowKeyInput(false);
  };

  const generateBotReply = async (userQuery) => {
    setIsTyping(true);
    const lower = userQuery.toLowerCase().trim();

    // 1. Try Gemini API if user configured a valid Gemini Key (starts with AIzaSy)
    if (apiKey && apiKey.startsWith('AIzaSy')) {
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{
                parts: [{
                  text: `You are Lunexa AI, a friendly smart education assistant for Lunexa (connecting school students with top mentors from IITs, NITs, BITS, AIIMS). Keep answers concise, encouraging, and clear. Question: ${userQuery}`
                }]
              }]
            })
          }
        );

        const data = await response.json();
        if (data.candidates && data.candidates[0]?.content?.parts[0]?.text) {
          const reply = data.candidates[0].content.parts[0].text;
          setMessages(prev => [
            ...prev,
            { id: Date.now(), sender: 'bot', text: reply, time: 'Just now' }
          ]);
          setIsTyping(false);
          return;
        }
      } catch (err) {
        console.warn("Gemini API notice, falling back to dynamic search engine:", err);
      }
    }

    // 2. Platform-specific Action Fast Path
    if (lower.includes('free') || lower.includes('complimentary') || lower.includes('trial')) {
      finishReply(" Every student gets 1 Complimentary Free Live Session upon signing up! You can claim it on our 'Pricing & Free Trial' page or from your Student Desk.");
      return;
    } else if (lower.includes('price') || lower.includes('token') || lower.includes('cost') || lower.includes('fee')) {
      finishReply(" Lunexa uses a transparent Token System: sessions range from ₹150 to ₹400/hr, paid directly to verified mentors. No lock-in subscriptions!");
      return;
    } else if (lower.includes('mentor') || lower.includes('teacher') || lower.includes('become') || lower.includes('join')) {
      finishReply(" Are you a college student? You can apply as a mentor through our Teacher Onboarding Wizard and earn honorarium payouts by guiding school students!");
      return;
    } else if (lower.includes('google') || lower.includes('login') || lower.includes('signup')) {
      finishReply(" We support 1-Click Google Sign-In! Click 'Log In / Sign Up' at the top right to log in as a Student or Teacher instantly.");
      return;
    } else if (lower === 'hi' || lower === 'hello' || lower === 'hey' || lower.startsWith('hi ') || lower.startsWith('hello ')) {
      finishReply("Hi there!  I'm Lunexa AI, your 24/7 learning & platform assistant! Ask me any question about your studies, subject doubts (Physics, Math, Chemistry, Biology, Psychology, CS), or Lunexa features!");
      return;
    }

    // 3. Dynamic Real-Time Knowledge Lookup Engine (Wikipedia REST API + DuckDuckGo)
    const cleanTerm = userQuery
      .replace(/^(explain|what is|tell me about|how does|define|why is|who is|meaning of|what are|describe)\s+/i, '')
      .trim();

    try {
      // Primary: Wikipedia REST API
      const wikiRes = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(cleanTerm || userQuery)}`);
      if (wikiRes.ok) {
        const wikiData = await wikiRes.json();
        if (wikiData.extract && wikiData.type !== 'disambiguation' && wikiData.extract.length > 30) {
          const formattedText = ` **${wikiData.title}:**\n\n${wikiData.extract}\n\n *Need deeper 1:1 guidance or subject tutoring? Connect with verified mentors under 'Find Tutors' or claim your 1 Complimentary Free Session!*`;
          finishReply(formattedText);
          return;
        }
      }
    } catch (e) {
      console.warn("Wikipedia lookup note:", e);
    }

    try {
      // Secondary: DuckDuckGo Instant Answer API
      const ddgRes = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(userQuery)}&format=json&no_html=1`);
      if (ddgRes.ok) {
        const ddgData = await ddgRes.json();
        if (ddgData.AbstractText) {
          const formattedText = ` **${ddgData.Heading || cleanTerm}:**\n\n${ddgData.AbstractText}\n\n *Want 1:1 doubt solving with top rankers? Book a session on Lunexa!*`;
          finishReply(formattedText);
          return;
        }
      }
    } catch (e) {
      console.warn("DuckDuckGo lookup note:", e);
    }

    // Fallback if search returns empty
    finishReply(` **${userQuery}:**\n\nI'm Lunexa AI, your 24/7 learning assistant. Whether you're studying Physics, Math, Chemistry, Biology, Psychology, or preparing for JEE/NEET/Boards, Lunexa connects you directly with top rankers from IITs, NITs, BITS, and AIIMS.\n\nBrowse our verified mentors or claim your 1 Complimentary Free Live Session!`);
  };

  const finishReply = (text) => {
    setTimeout(() => {
      setMessages(prev => [
        ...prev,
        { id: Date.now(), sender: 'bot', text: text, time: 'Just now' }
      ]);
      setIsTyping(false);
    }, 400);
  };

  const handleSend = (textOverride) => {
    const query = (textOverride || inputMsg).trim();
    if (!query) return;

    setMessages(prev => [
      ...prev,
      { id: Date.now(), sender: 'user', text: query, time: 'Just now' }
    ]);
    setInputMsg('');
    generateBotReply(query);
  };

  return (
    <div className="fixed bottom-5 right-5 z-50">
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 text-white shadow-2xl shadow-indigo-600/40 hover:scale-105 active:scale-95 transition-all duration-200 border border-indigo-400/30"
        >
          <div className="relative flex items-center justify-center">
            <span className="text-lg"></span>
          </div>
          <span className="text-xs font-bold tracking-wide">Lunexa AI</span>
          <span className="hidden group-hover:inline-block text-[11px] text-indigo-100 font-medium border-l border-indigo-400/40 pl-2">
            Ask doubts 24/7
          </span>
        </button>
      )}

      {isOpen && (
        <div className="w-[350px] sm:w-[380px] h-[520px] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col justify-between overflow-hidden animate-fade-up">
          
          <div className="p-4 bg-gradient-to-r from-indigo-600 to-violet-600 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-base font-bold shadow-sm">
                
              </div>
              <div>
                <h3 className="font-bold text-xs">Lunexa AI Assistant</h3>
                <div className="flex items-center gap-1.5 text-[10px] text-indigo-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>{apiKey ? 'Gemini 1.5 Flash Connected' : 'Lunexa AI • Online 24/7'}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowKeyInput(!showKeyInput)}
                className="p-1.5 rounded-xl hover:bg-white/20 text-indigo-100 transition-colors"
                title="API Key Settings"
              >
                
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-xl hover:bg-white/20 text-indigo-100 transition-colors"
                title="Close Chat"
              >
                <Icon name="x" className="w-4 h-4" />
              </button>
            </div>
          </div>

          {showKeyInput && (
            <div className="p-3.5 bg-indigo-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-xs space-y-2">
              <div className="flex items-center justify-between font-bold text-slate-800 dark:text-slate-200 text-[11px]">
                <span> Custom Gemini API Key</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-normal">Optional</span>
              </div>
              <input
                type="password"
                placeholder="Paste Gemini API Key (AIzaSy...)"
                value={apiKey}
                onChange={(e) => handleSaveApiKey(e.target.value)}
                className="w-full p-2 text-xs rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
              />
              <p className="text-[10px] text-slate-500 leading-tight">
                Get a free key from <a href="https://aistudio.google.com" target="_blank" rel="noreferrer" className="text-indigo-600 dark:text-indigo-400 underline font-medium">aistudio.google.com</a>. Leave blank to use built-in Lunexa AI.
              </p>
            </div>
          )}

          <div className="p-4 flex-1 overflow-y-auto space-y-3 text-xs">
            {messages.map((m) => {
              const isBot = m.sender === 'bot';
              return (
                <div
                  key={m.id}
                  className={`flex gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
                >
                  {isBot && (
                    <div className="w-7 h-7 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs flex-shrink-0">
                      
                    </div>
                  )}
                  <div
                    className={`max-w-[82%] p-3 rounded-2xl leading-relaxed ${
                      isBot
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200/60 dark:border-slate-700/60'
                        : 'bg-indigo-600 text-white shadow-sm'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex gap-2.5 justify-start items-center">
                <div className="w-7 h-7 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center text-xs">
                  
                </div>
                <div className="bg-slate-100 dark:bg-slate-800 p-2.5 rounded-2xl text-slate-400 text-xs flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping"></span>
                  <span>Lunexa AI is thinking...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto text-[11px]">
            <button
              type="button"
              onClick={() => handleSend("How to get 1 free live session?")}
              className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 whitespace-nowrap hover:border-indigo-500"
            >
               Claim Free Session
            </button>
            <button
              type="button"
              onClick={() => handleSend("Find Calculus Mentor")}
              className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 whitespace-nowrap hover:border-indigo-500"
            >
               Find Mentor
            </button>
            <button
              type="button"
              onClick={() => handleSend("How does token payout work?")}
              className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 whitespace-nowrap hover:border-indigo-500"
            >
               Token Pricing
            </button>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask Lunexa AI anything..."
              value={inputMsg}
              onChange={(e) => setInputMsg(e.target.value)}
              className="flex-1 p-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30"
            >
              <Icon name="send" className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}
    </div>
  );
}

// =========================================================================
// Lunexa LANDING PAGE (Hero, Live Session Demo, Feature Grid, Leaderboard)
// =========================================================================
function LunexaLandingPage({ onFindMentor, onRegisterMentor, onOpenPricing, onOpenLiveRoom, mentors, batches, onSelectMentor }) {
  const [matchSubject, setMatchSubject] = useState('Calculus');
  const [matchTopic, setMatchTopic] = useState('Integration by parts');
  const [isMatching, setIsMatching] = useState(false);
  const [matchedMentor, setMatchedMentor] = useState(null);

  const handleInstantMatch = () => {
    setIsMatching(true);
    setMatchedMentor(null);
    setTimeout(() => {
      setIsMatching(false);
      setMatchedMentor(mentors[2]); // Rahul Sharma IIT Bombay
    }, 2500);
  };

  return (
    <div className="space-y-20 py-10">

      {/* 1. HERO SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-6 pb-12">

        {/* Top Tag */}
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 mb-6">
          <span></span>
          <span>Next-Generation Peer Learning Platform</span>
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight max-w-4xl mx-auto">
          Smart Education Powered by{" "}
          <span className="bg-gradient-to-r from-[#4F46E5] via-[#6366F1] to-[#10B981] bg-clip-text text-transparent">
            Peer Mentorship.
          </span>
        </h1>

        {/* Sub-headline */}
        <p className="mt-6 text-lg sm:text-xl text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Learn in live interactive sessions or small batches directly from top college students who recently cleared the exams you are preparing for.
        </p>

        {/* CTA Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onFindMentor}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-semibold text-xs sm:text-sm text-white bg-[#4F46E5] hover:bg-[#4338CA] shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
          >
            <span>Find a Mentor Now</span>
            <Icon name="arrow-right" className="w-4 h-4" />
          </button>
          <button
            onClick={onRegisterMentor}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-semibold text-xs sm:text-sm text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-indigo-500 transition-all shadow-sm"
          >
            Register as College Mentor
          </button>
        </div>

        {/* Metric Badges */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-8 text-xs font-semibold text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5] flex items-center justify-center font-bold"></div>
            <span><strong className="text-slate-900 dark:text-white font-extrabold">10,000+</strong> Live Hours</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold"></div>
            <span><strong className="text-slate-900 dark:text-white font-extrabold">500+</strong> Verified College Mentors</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center font-bold"></div>
            <span><strong className="text-slate-900 dark:text-white font-extrabold">4.9/5</strong> Rating</span>
          </div>
        </div>

        {/* INTERACTIVE LIVE CLASSROOM PREVIEW STUDIO */}
        <LiveClassroomPreviewCard onOpenLiveRoom={onOpenLiveRoom} />

      </section>

      {/* 2. CORE FEATURES (Everything you need to learn smarter) */}
      <section className="py-16 bg-slate-50 dark:bg-slate-900/50 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
              Everything you need to{" "}
              <span className="text-[#4F46E5]">learn smarter</span>
            </h2>
            <p className="text-slate-500 text-sm mt-2">
              High-friction coaching replaced with fast, peer-to-peer micro-learning.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Card 1 */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-[#4F46E5] flex items-center justify-center mb-5">
                <Icon name="video" className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-2">
                Live 1:1 Instant Mentorship
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Connect via live video and whiteboard canvas with students who recently scored top percentiles in JEE, NEET, and CBSE boards.
              </p>
            </div>

            {/* Card 2 */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-5">
                <Icon name="users" className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-2">
                Structured College-Led Batch Courses
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Join cohort batches with 15–20 peers. Master entire chapters with curriculum-aligned assignments and doubt sessions.
              </p>
            </div>

            {/* Card 3 */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-5">
                <Icon name="zap" className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-2">
                Smart AI Study Planner & Doubt Rooms
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                AI maps your weak areas based on doubt history, schedules review reminders, and pairs you with peer practice rooms.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* 3. CTA BANNER (Ready to start learning?) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-[#4F46E5] rounded-3xl p-10 sm:p-14 text-white text-center shadow-xl relative overflow-hidden">
          <h2 className="text-2xl sm:text-3xl font-bold mb-3">Ready to start learning?</h2>
          <p className="text-indigo-100 text-xs sm:text-sm max-w-xl mx-auto mb-8">
            Join thousands of students getting 1:1 help from verified mentors from IITs, NITs, BITS, and AIIMS.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onFindMentor}
              className="px-6 py-3 rounded-xl font-semibold text-xs bg-white text-[#4F46E5] hover:bg-slate-100 shadow-md transition-all"
            >
              Find a Mentor
            </button>
            <button
              onClick={onRegisterMentor}
              className="px-6 py-3 rounded-xl font-semibold text-xs text-white border border-white/40 hover:bg-white/10 transition-all"
            >
              Become a Mentor
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}


// =========================================================================
// SUBJECT DOODLE BACKGROUNDS — animated SVGs per subject
// =========================================================================
const SUBJECT_DOODLES = {
  All: {
    color: '#4F46E5', lightBg: '#EEF2FF', emoji: '',
    label: 'All Subjects',
    doodle: (
      <svg width="100%" height="100%" viewBox="0 0 800 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ opacity: 0.07 }}>
        <text x="30" y="80" fontSize="48" fontFamily="serif" fill="#4F46E5">∑</text>
        <text x="160" y="120" fontSize="32" fontFamily="monospace" fill="#10B981">DNA</text>
        <text x="300" y="60" fontSize="42" fontFamily="serif" fill="#6366F1"></text>
        <text x="450" y="100" fontSize="36" fontFamily="monospace" fill="#4F46E5">01101</text>
        <text x="600" y="70" fontSize="38" fontFamily="serif" fill="#10B981"></text>
        <circle cx="100" cy="200" r="40" stroke="#4F46E5" strokeWidth="2" strokeDasharray="6 4" />
        <circle cx="400" cy="300" r="60" stroke="#10B981" strokeWidth="2" strokeDasharray="8 4" />
        <circle cx="700" cy="250" r="35" stroke="#6366F1" strokeWidth="2" strokeDasharray="5 3" />
        <line x1="50" y1="320" x2="750" y2="320" stroke="#4F46E5" strokeWidth="1" strokeDasharray="10 6" />
      </svg>
    )
  },
  Maths: {
    color: '#4F46E5', lightBg: '#EEF2FF', emoji: '',
    label: 'Mathematics',
    doodle: (
      <svg width="100%" height="100%" viewBox="0 0 800 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ opacity: 0.08 }}>
        {/* Integral signs */}
        <text x="20" y="100" fontSize="80" fontFamily="serif" fill="#4F46E5" style={{ fontStyle: 'italic' }}>∫</text>
        <text x="110" y="85" fontSize="28" fontFamily="serif" fill="#4F46E5">x² dx</text>
        {/* Pi symbol */}
        <text x="280" y="110" fontSize="72" fontFamily="serif" fill="#6366F1">π</text>
        {/* Sigma */}
        <text x="400" y="90" fontSize="60" fontFamily="serif" fill="#4F46E5">Σ</text>
        <text x="470" y="85" fontSize="20" fontFamily="serif" fill="#6366F1">n=0</text>
        {/* Delta */}
        <text x="580" y="100" fontSize="64" fontFamily="serif" fill="#818CF8">Δ</text>
        {/* sqrt */}
        <text x="680" y="90" fontSize="36" fontFamily="serif" fill="#4F46E5">√x</text>
        {/* Grid lines */}
        <line x1="0" y1="200" x2="800" y2="200" stroke="#4F46E5" strokeWidth="1" strokeDasharray="8 6" />
        <line x1="400" y1="0" x2="400" y2="400" stroke="#4F46E5" strokeWidth="1" strokeDasharray="8 6" />
        {/* Sine wave */}
        <path d="M0 280 Q100 230 200 280 Q300 330 400 280 Q500 230 600 280 Q700 330 800 280" stroke="#6366F1" strokeWidth="2" fill="none" strokeDasharray="6 4" />
        {/* Parabola */}
        <path d="M100 380 Q400 160 700 380" stroke="#818CF8" strokeWidth="2" fill="none" />
        {/* Angle */}
        <line x1="100" y1="370" x2="200" y2="320" stroke="#4F46E5" strokeWidth="1.5" />
        <line x1="100" y1="370" x2="180" y2="370" stroke="#4F46E5" strokeWidth="1.5" />
        <text x="150" y="365" fontSize="14" fill="#4F46E5">θ</text>
        {/* Theorem text */}
        <text x="30" y="350" fontSize="13" fontFamily="monospace" fill="#6366F1">a² + b² = c²</text>
        <text x="560" y="350" fontSize="13" fontFamily="monospace" fill="#4F46E5">f(x) = mx + b</text>
      </svg>
    )
  },
  Physics: {
    color: '#0EA5E9', lightBg: '#E0F2FE', emoji: '',
    label: 'Physics',
    doodle: (
      <svg width="100%" height="100%" viewBox="0 0 800 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ opacity: 0.08 }}>
        {/* Atom diagram */}
        <ellipse cx="150" cy="160" rx="80" ry="30" stroke="#0EA5E9" strokeWidth="2" transform="rotate(-30 150 160)" />
        <ellipse cx="150" cy="160" rx="80" ry="30" stroke="#0EA5E9" strokeWidth="2" transform="rotate(30 150 160)" />
        <ellipse cx="150" cy="160" rx="80" ry="30" stroke="#7DD3FC" strokeWidth="1.5" />
        <circle cx="150" cy="160" r="10" fill="#0EA5E9" />
        {/* Einstein equation */}
        <text x="290" y="80" fontSize="28" fontFamily="serif" fill="#0EA5E9">E = mc²</text>
        {/* Wave */}
        <path d="M270 160 Q310 120 350 160 Q390 200 430 160 Q470 120 510 160 Q550 200 590 160 Q630 120 670 160" stroke="#38BDF8" strokeWidth="2.5" fill="none" />
        {/* Arrow / force */}
        <line x1="290" y1="260" x2="490" y2="260" stroke="#0EA5E9" strokeWidth="2.5" markerEnd="url(#arr)" />
        <text x="370" y="250" fontSize="16" fontFamily="serif" fill="#0EA5E9">F</text>
        {/* Newton gravity */}
        <text x="520" y="120" fontSize="20" fontFamily="serif" fill="#38BDF8">F = Gm₁m₂/r²</text>
        {/* Light ray */}
        <line x1="580" y1="200" x2="760" y2="200" stroke="#FCD34D" strokeWidth="2" strokeDasharray="12 6" />
        <text x="590" y="190" fontSize="13" fontFamily="monospace" fill="#FCD34D">c = 3×10⁸ m/s</text>
        {/* Circuit symbol */}
        <rect x="580" y="280" width="40" height="20" rx="2" stroke="#0EA5E9" strokeWidth="2" fill="none" />
        <line x1="540" y1="290" x2="580" y2="290" stroke="#0EA5E9" strokeWidth="2" />
        <line x1="620" y1="290" x2="660" y2="290" stroke="#0EA5E9" strokeWidth="2" />
        <text x="20" y="340" fontSize="13" fontFamily="monospace" fill="#38BDF8">v = u + at</text>
        <text x="280" y="340" fontSize="13" fontFamily="monospace" fill="#0EA5E9">KE = ½mv²</text>
        <text x="550" y="370" fontSize="13" fontFamily="monospace" fill="#7DD3FC">P = IV</text>
      </svg>
    )
  },
  Chemistry: {
    color: '#10B981', lightBg: '#D1FAE5', emoji: '',
    label: 'Chemistry',
    doodle: (
      <svg width="100%" height="100%" viewBox="0 0 800 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ opacity: 0.08 }}>
        {/* Benzene ring */}
        <polygon points="120,100 160,78 200,100 200,145 160,167 120,145" stroke="#10B981" strokeWidth="2.5" fill="none" />
        <polygon points="135,110 160,95 185,110 185,140 160,155 135,140" stroke="#10B981" strokeWidth="1.5" fill="none" />
        {/* Water molecule */}
        <circle cx="400" cy="120" r="22" stroke="#34D399" strokeWidth="2" fill="none" />
        <text x="392" y="128" fontSize="16" fontFamily="serif" fill="#10B981">O</text>
        <circle cx="350" cy="80" r="14" stroke="#34D399" strokeWidth="2" fill="none" />
        <text x="345" y="87" fontSize="12" fontFamily="serif" fill="#10B981">H</text>
        <circle cx="450" cy="80" r="14" stroke="#34D399" strokeWidth="2" fill="none" />
        <text x="445" y="87" fontSize="12" fontFamily="serif" fill="#10B981">H</text>
        <line x1="363" y1="90" x2="385" y2="108" stroke="#10B981" strokeWidth="2" />
        <line x1="415" y1="108" x2="437" y2="90" stroke="#10B981" strokeWidth="2" />
        {/* Flask doodle */}
        <path d="M600 60 L600 120 L560 200 L640 200 Z" stroke="#10B981" strokeWidth="2" fill="none" />
        <line x1="585" y1="60" x2="615" y2="60" stroke="#10B981" strokeWidth="2" />
        <ellipse cx="600" cy="180" rx="28" ry="10" fill="#10B981" opacity="0.3" />
        {/* Bubbles in flask */}
        <circle cx="590" cy="155" r="4" stroke="#34D399" strokeWidth="1.5" fill="none" />
        <circle cx="610" cy="165" r="3" stroke="#34D399" strokeWidth="1.5" fill="none" />
        {/* Periodic table elements */}
        <text x="30" y="250" fontSize="20" fontFamily="monospace" fill="#10B981" fontWeight="bold">H</text>
        <text x="55" y="250" fontSize="20" fontFamily="monospace" fill="#34D399" fontWeight="bold">He</text>
        <text x="90" y="250" fontSize="20" fontFamily="monospace" fill="#10B981" fontWeight="bold">Li</text>
        <text x="125" y="250" fontSize="20" fontFamily="monospace" fill="#34D399" fontWeight="bold">Na</text>
        <text x="30" y="280" fontSize="14" fontFamily="monospace" fill="#6EE7B7">NaCl → Na⁺ + Cl⁻</text>
        <text x="280" y="280" fontSize="14" fontFamily="monospace" fill="#10B981">2H₂ + O₂ → 2H₂O</text>
        <text x="560" y="280" fontSize="14" fontFamily="monospace" fill="#34D399">pH = -log[H⁺]</text>
        {/* DNA-like helix */}
        <path d="M680 60 Q700 90 680 120 Q660 150 680 180 Q700 210 680 240" stroke="#10B981" strokeWidth="2" fill="none" />
        <path d="M720 60 Q700 90 720 120 Q740 150 720 180 Q700 210 720 240" stroke="#34D399" strokeWidth="2" fill="none" />
        <line x1="680" y1="90" x2="720" y2="90" stroke="#6EE7B7" strokeWidth="1.5" />
        <line x1="680" y1="120" x2="720" y2="120" stroke="#6EE7B7" strokeWidth="1.5" />
        <line x1="680" y1="150" x2="720" y2="150" stroke="#6EE7B7" strokeWidth="1.5" />
        <line x1="680" y1="180" x2="720" y2="180" stroke="#6EE7B7" strokeWidth="1.5" />
        <line x1="680" y1="210" x2="720" y2="210" stroke="#6EE7B7" strokeWidth="1.5" />
      </svg>
    )
  },
  Biology: {
    color: '#F59E0B', lightBg: '#FEF3C7', emoji: '',
    label: 'Biology',
    doodle: (
      <svg width="100%" height="100%" viewBox="0 0 800 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ opacity: 0.08 }}>
        {/* DNA double helix */}
        <path d="M60 30 Q90 80 60 130 Q30 180 60 230 Q90 280 60 330 Q30 380 60 400" stroke="#F59E0B" strokeWidth="3" fill="none" />
        <path d="M120 30 Q90 80 120 130 Q150 180 120 230 Q90 280 120 330 Q150 380 120 400" stroke="#FBBF24" strokeWidth="3" fill="none" />
        <line x1="60" y1="70" x2="120" y2="70" stroke="#FCD34D" strokeWidth="2" />
        <line x1="60" y1="110" x2="120" y2="110" stroke="#FCD34D" strokeWidth="2" />
        <line x1="60" y1="150" x2="120" y2="150" stroke="#FCD34D" strokeWidth="2" />
        <line x1="60" y1="190" x2="120" y2="190" stroke="#FCD34D" strokeWidth="2" />
        <line x1="60" y1="230" x2="120" y2="230" stroke="#FCD34D" strokeWidth="2" />
        <line x1="60" y1="270" x2="120" y2="270" stroke="#FCD34D" strokeWidth="2" />
        <line x1="60" y1="310" x2="120" y2="310" stroke="#FCD34D" strokeWidth="2" />
        <line x1="60" y1="350" x2="120" y2="350" stroke="#FCD34D" strokeWidth="2" />
        {/* Cell */}
        <ellipse cx="350" cy="160" rx="110" ry="80" stroke="#F59E0B" strokeWidth="2.5" fill="none" />
        <ellipse cx="350" cy="160" rx="40" ry="30" stroke="#FBBF24" strokeWidth="2" fill="none" />
        <text x="334" y="165" fontSize="13" fontFamily="serif" fill="#F59E0B">nucleus</text>
        {/* Mitochondria shape */}
        <ellipse cx="310" cy="100" rx="25" ry="12" stroke="#FCD34D" strokeWidth="1.5" fill="none" />
        <path d="M295 100 Q305 88 315 100 Q305 112 295 100" stroke="#F59E0B" strokeWidth="1.5" fill="none" />
        {/* Labels */}
        <text x="200" y="310" fontSize="14" fontFamily="monospace" fill="#F59E0B">Photosynthesis</text>
        <text x="200" y="330" fontSize="12" fontFamily="monospace" fill="#FBBF24">6CO₂+6H₂O→C₆H₁₂O₆+6O₂</text>
        {/* Leaf outline */}
        <path d="M560 60 Q620 30 680 80 Q700 160 620 200 Q560 180 540 140 Q520 100 560 60Z" stroke="#F59E0B" strokeWidth="2" fill="none" />
        <line x1="600" y1="60" x2="580" y2="190" stroke="#FBBF24" strokeWidth="1.5" />
        <line x1="580" y1="120" x2="550" y2="100" stroke="#FCD34D" strokeWidth="1" />
        <line x1="600" y1="100" x2="660" y2="80" stroke="#FCD34D" strokeWidth="1" />
        <line x1="595" y1="140" x2="650" y2="130" stroke="#FCD34D" strokeWidth="1" />
        <line x1="580" y1="170" x2="610" y2="175" stroke="#FCD34D" strokeWidth="1" />
        <text x="560" y="340" fontSize="13" fontFamily="monospace" fill="#FBBF24">ATP synthesis</text>
      </svg>
    )
  },
  CS: {
    color: '#8B5CF6', lightBg: '#EDE9FE', emoji: '',
    label: 'Coding & CS',
    doodle: (
      <svg width="100%" height="100%" viewBox="0 0 800 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ opacity: 0.09 }}>
        {/* Code snippets */}
        <text x="20" y="60" fontSize="14" fontFamily="monospace" fill="#8B5CF6">{"function solve(n) {"}</text>
        <text x="20" y="82" fontSize="14" fontFamily="monospace" fill="#A78BFA">{"  if (n <= 1) return n;"}</text>
        <text x="20" y="104" fontSize="14" fontFamily="monospace" fill="#8B5CF6">{"  return solve(n-1) + solve(n-2);"}</text>
        <text x="20" y="126" fontSize="14" fontFamily="monospace" fill="#C4B5FD">{"}"}</text>
        {/* Binary */}
        <text x="420" y="50" fontSize="12" fontFamily="monospace" fill="#8B5CF6" opacity="0.9">{"01001000 01101001"}</text>
        <text x="420" y="70" fontSize="12" fontFamily="monospace" fill="#A78BFA" opacity="0.7">{"10010011 00110011"}</text>
        <text x="420" y="90" fontSize="12" fontFamily="monospace" fill="#C4B5FD" opacity="0.5">{"01101111 01110111"}</text>
        {/* Flow chart */}
        <rect x="320" y="160" width="80" height="36" rx="6" stroke="#8B5CF6" strokeWidth="2" fill="none" />
        <text x="340" y="183" fontSize="13" fontFamily="monospace" fill="#8B5CF6">START</text>
        <line x1="360" y1="196" x2="360" y2="230" stroke="#8B5CF6" strokeWidth="2" />
        <polygon points="340,230 380,230 360,260" stroke="#8B5CF6" strokeWidth="2" fill="none" />
        <text x="348" y="248" fontSize="11" fontFamily="monospace" fill="#8B5CF6">if</text>
        <line x1="360" y1="260" x2="360" y2="290" stroke="#8B5CF6" strokeWidth="2" />
        <rect x="320" y="290" width="80" height="36" rx="6" stroke="#A78BFA" strokeWidth="2" fill="none" />
        <text x="342" y="313" fontSize="13" fontFamily="monospace" fill="#A78BFA">END</text>
        {/* Network graph */}
        <circle cx="620" cy="100" r="16" stroke="#8B5CF6" strokeWidth="2" fill="none" />
        <circle cx="680" cy="60" r="12" stroke="#A78BFA" strokeWidth="2" fill="none" />
        <circle cx="720" cy="130" r="12" stroke="#A78BFA" strokeWidth="2" fill="none" />
        <circle cx="660" cy="160" r="12" stroke="#C4B5FD" strokeWidth="2" fill="none" />
        <line x1="620" y1="100" x2="680" y2="60" stroke="#8B5CF6" strokeWidth="1.5" />
        <line x1="620" y1="100" x2="720" y2="130" stroke="#8B5CF6" strokeWidth="1.5" />
        <line x1="720" y1="130" x2="660" y2="160" stroke="#A78BFA" strokeWidth="1.5" />
        <line x1="680" y1="60" x2="720" y2="130" stroke="#C4B5FD" strokeWidth="1.5" />
        {/* Big O */}
        <text x="560" y="260" fontSize="28" fontFamily="monospace" fill="#8B5CF6">O(log n)</text>
        <text x="560" y="290" fontSize="18" fontFamily="monospace" fill="#A78BFA">O(n²)</text>
        {/* Terminal prompt */}
        <text x="20" y="320" fontSize="14" fontFamily="monospace" fill="#A78BFA">{"$ git commit -m 'fix bug'"}</text>
        <text x="20" y="342" fontSize="14" fontFamily="monospace" fill="#C4B5FD">{"$ npm install peerlearn"}</text>
        <text x="20" y="364" fontSize="14" fontFamily="monospace" fill="#8B5CF6">{">>> Hello World!"}</text>
      </svg>
    )
  }
};

function MentorDiscoveryPage({
  mentors,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  modeFilter,
  setModeFilter,
  maxPrice,
  setMaxPrice,
  onBookMentor,
  onViewProfile
}) {
  const subjectConfig = SUBJECT_DOODLES[selectedCategory] || SUBJECT_DOODLES['All'];
  const [doodleKey, setDoodleKey] = useState(0);

  const handleCategoryChange = (cat) => {
    setSelectedCategory(cat);
    setDoodleKey(k => k + 1);
  };

  const subjects = [
    { id: 'All', emoji: '', label: 'All' },
    { id: 'Maths', emoji: '', label: 'Maths', color: '#4F46E5', bg: '#EEF2FF' },
    { id: 'Physics', emoji: '', label: 'Physics', color: '#0EA5E9', bg: '#E0F2FE' },
    { id: 'Chemistry', emoji: '', label: 'Chemistry', color: '#10B981', bg: '#D1FAE5' },
    { id: 'Biology', emoji: '', label: 'Biology', color: '#F59E0B', bg: '#FEF3C7' },
    { id: 'CS', emoji: '', label: 'CS / Code', color: '#8B5CF6', bg: '#EDE9FE' },
  ];

  return (
    <div style={{ position: 'relative', overflow: 'hidden', minHeight: '100vh' }}>

      {/*  Animated doodle background layer  */}
      <div
        key={doodleKey}
        style={{
          position: 'fixed', inset: 0, zIndex: 0, pointerEvents: 'none',
          transition: 'opacity 0.5s ease',
          animation: 'doodleFadeIn 0.6s ease forwards'
        }}
      >
        {subjectConfig.doodle}
      </div>
      <style>{`
        @keyframes doodleFadeIn {
          from { opacity: 0; transform: scale(1.03); }
          to   { opacity: 1; transform: scale(1); }
        }
      `}</style>

      {/*  Page content  */}
      <div style={{ position: 'relative', zIndex: 1 }} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <span style={{ fontSize: 28 }}>{subjectConfig.emoji}</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Find Verified{' '}
              <span style={{ color: subjectConfig.color }}>
                {selectedCategory === 'All' ? 'College Mentors' : subjectConfig.label + ' Mentors'}
              </span>
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 ml-10">
            Connect with top rankers from IITs, NITs, BITS & AIIMS for 1:1 doubt sessions and batch classes.
          </p>
        </div>

        {/*  Subject Pill Tabs  */}
        <div className="flex flex-wrap gap-2 mb-6">
          {subjects.map(s => {
            const isActive = selectedCategory === s.id;
            return (
              <button
                key={s.id}
                onClick={() => handleCategoryChange(s.id)}
                style={{
                  background: isActive ? (s.color || '#4F46E5') : 'white',
                  color: isActive ? 'white' : (s.color || '#64748b'),
                  border: `2px solid ${isActive ? (s.color || '#4F46E5') : '#e2e8f0'}`,
                  borderRadius: 99,
                  padding: '6px 16px',
                  fontSize: 12,
                  fontWeight: 700,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  transition: 'all 0.2s ease',
                  boxShadow: isActive ? `0 4px 14px ${(s.color || '#4F46E5')}40` : '0 1px 3px rgba(0,0,0,0.06)',
                  transform: isActive ? 'scale(1.06)' : 'scale(1)',
                }}
              >
                <span style={{ fontSize: 15 }}>{s.emoji}</span>
                {s.label}
              </button>
            );
          })}
        </div>

        {/*  Filter Bar  */}
        <div
          className="rounded-2xl p-4 mb-8 space-y-3"
          style={{
            background: 'rgba(255,255,255,0.85)',
            backdropFilter: 'blur(12px)',
            border: '1.5px solid rgba(226,232,240,0.8)',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
          }}
        >
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
            <div className="md:col-span-6 relative">
              <Icon name="search" className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search by mentor name, college, or topic..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 bg-white/80 text-slate-800 focus:outline-none focus:ring-2"
                style={{ focusRingColor: subjectConfig.color }}
              />
            </div>

            <div className="md:col-span-6 flex items-center bg-slate-100/80 p-1 rounded-xl text-xs">
              {[
                { id: 'all', label: '⊕ All' },
                { id: '1on1', label: ' 1:1 Mentors' },
                { id: 'batches', label: ' Live Batches' }
              ].map(m => (
                <button
                  key={m.id}
                  onClick={() => setModeFilter(m.id)}
                  className={`flex-1 py-1.5 rounded-lg font-semibold transition-all ${modeFilter === m.id
                    ? 'bg-white text-slate-800 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800'
                    }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-3">
              <span className="text-slate-500 font-medium">Max Fee:</span>
              <input
                type="range" min="0" max="500" step="50"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-32"
                style={{ accentColor: subjectConfig.color }}
              />
              <span className="font-bold" style={{ color: subjectConfig.color }}>
                {maxPrice === 0 ? 'Free Only' : `₹${maxPrice}/hr`}
              </span>
            </div>
            <span className="text-slate-400">
              <strong style={{ color: subjectConfig.color }}>{mentors.length}</strong> Mentors Available
            </span>
          </div>
        </div>

        {/*  Mentor Cards Grid  */}
        {mentors.length === 0 ? (
          <div className="text-center py-24">
            <div style={{ fontSize: 56, marginBottom: 12 }}></div>
            <p className="text-slate-500 font-semibold">No mentors found. Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mentors.map(m => (
              <div
                key={m.id}
                style={{
                  background: 'rgba(255,255,255,0.88)',
                  backdropFilter: 'blur(16px)',
                  border: '1.5px solid rgba(226,232,240,0.7)',
                  borderRadius: 24,
                  padding: 20,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  boxShadow: '0 2px 16px rgba(0,0,0,0.06)',
                  transition: 'all 0.2s ease',
                  cursor: 'default'
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.boxShadow = `0 8px 32px ${subjectConfig.color}28`;
                  e.currentTarget.style.transform = 'translateY(-3px)';
                  e.currentTarget.style.borderColor = subjectConfig.color + '50';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.boxShadow = '0 2px 16px rgba(0,0,0,0.06)';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.borderColor = 'rgba(226,232,240,0.7)';
                }}
              >
                <div>
                  {/* Card Header */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
                    {/* Avatar with color-themed gradient ring */}
                    <div style={{ position: 'relative', flexShrink: 0 }}>
                      <div style={{
                        width: 64, height: 64, borderRadius: 18, padding: 2,
                        background: `linear-gradient(135deg,${subjectConfig.color},${subjectConfig.color}80)`,
                        flexShrink: 0
                      }}>
                        <img
                          src={m.avatar}
                          alt={m.name}
                          style={{ width: '100%', height: '100%', borderRadius: 14, objectFit: 'cover', display: 'block' }}
                        />
                      </div>
                      <span style={{
                        position: 'absolute', bottom: -2, right: -2,
                        width: 12, height: 12, background: '#10B981',
                        border: '2px solid white', borderRadius: '50%'
                      }}></span>
                    </div>

                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 2 }}>
                        <span style={{ fontWeight: 700, fontSize: 14, color: '#1E293B', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.name}</span>
                        <Icon name="shield-check" className="w-3.5 h-3.5 text-blue-500" style={{ flexShrink: 0 }} />
                      </div>
                      <div style={{ fontSize: 11, color: '#64748B', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', lineHeight: 1.4 }}>{m.college}</div>
                      <div style={{ fontSize: 11, color: '#94A3B8', lineHeight: 1.4, marginBottom: 4 }}>{m.year}</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                        <span style={{ color: '#F59E0B', fontSize: 13 }}></span>
                        <span style={{ fontSize: 12, fontWeight: 700, color: '#334155' }}>{m.rating}</span>
                        <span style={{ fontSize: 10, color: '#94A3B8' }}>({m.reviewsCount} reviews)</span>
                      </div>
                    </div>
                  </div>

                  {/* Subject tags — themed to selected subject color */}
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
                    {m.subjects.map(s => (
                      <span
                        key={s}
                        style={{
                          fontSize: 10, fontWeight: 700,
                          padding: '2px 8px', borderRadius: 6,
                          background: subjectConfig.lightBg,
                          color: subjectConfig.color
                        }}
                      >
                        {s}
                      </span>
                    ))}
                  </div>

                  <p style={{ fontSize: 12, color: '#475569', lineHeight: 1.6, marginBottom: 10, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{m.bio}</p>

                  {m.batchBadge && (
                    <div style={{ padding: '7px 10px', borderRadius: 10, background: '#ECFDF5', color: '#059669', fontSize: 11, fontWeight: 600, marginBottom: 10 }}>
                      {m.batchBadge}
                    </div>
                  )}
                </div>

                {/* Card Footer */}
                <div style={{ paddingTop: 12, borderTop: '1.5px solid #F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 13, fontWeight: 800, color: '#1E293B' }}>
                    {m.hourlyRate === 0 ? (
                      <span style={{ color: '#10B981' }}>Free </span>
                    ) : `₹${m.hourlyRate}/hr`}
                  </span>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button
                      onClick={() => onViewProfile(m)}
                      style={{
                        padding: '6px 12px', fontSize: 11, fontWeight: 600,
                        color: '#64748B', background: '#F8FAFC',
                        border: '1.5px solid #E2E8F0', borderRadius: 10,
                        cursor: 'pointer', transition: 'all 0.15s'
                      }}
                    >Profile</button>
                    <button
                      onClick={() => onBookMentor(m)}
                      style={{
                        padding: '6px 14px', fontSize: 11, fontWeight: 700,
                        color: 'white',
                        background: `linear-gradient(135deg,${subjectConfig.color},${subjectConfig.color}cc)`,
                        border: 'none', borderRadius: 10,
                        cursor: 'pointer',
                        boxShadow: `0 3px 10px ${subjectConfig.color}40`,
                        transition: 'all 0.15s'
                      }}
                    >Book 1:1</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </div>
  );
}



// =========================================================================
// BATCH CLASSES PAGE
// =========================================================================
function BatchClassesPage({ batches, onEnrollBatch }) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Structured College-Led Batch Courses
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Join small cohorts led by college toppers. Complete chapter mastery with live doubt calls.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {batches.map(b => (
          <div key={b.id} className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-50 text-[#4F46E5]">{b.category}</span>
                <span className="text-xs font-bold text-amber-500"> {b.rating}</span>
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">{b.title}</h3>
              <div className="text-xs text-slate-500 mb-4">{b.instructor} • {b.schedule}</div>
              <div className="text-xs text-slate-400 mb-1">Seats: {b.seatsFilled} / {b.seatsTotal}</div>
              <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden mb-4">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${(b.seatsFilled / b.seatsTotal) * 100}%` }}></div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
              <span className="text-base font-extrabold">₹{b.price}</span>
              <button
                onClick={() => onEnrollBatch(b)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#4F46E5] hover:bg-[#4338CA]"
              >
                Enroll in Batch
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// =========================================================================
// HOW IT WORKS PAGE
// =========================================================================
function HowItWorksSection({ onGetStarted }) {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-12">
      <div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">How Lunexa Works</h1>
        <p className="text-sm text-slate-500 mt-2">Institutional verification meets instant 1:1 peer mentorship.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="w-10 h-10 rounded-full bg-[#4F46E5] text-white font-bold mx-auto mb-3 flex items-center justify-center">1</div>
          <h3 className="font-bold text-sm mb-1 text-slate-900 dark:text-white">Post Doubt or Search</h3>
          <p className="text-xs text-slate-500">Pick your topic or chapter. Connect with verified college mentors who cleared that exact exam.</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="w-10 h-10 rounded-full bg-emerald-500 text-white font-bold mx-auto mb-3 flex items-center justify-center">2</div>
          <h3 className="font-bold text-sm mb-1 text-slate-900 dark:text-white">Interactive Whiteboard</h3>
          <p className="text-xs text-slate-500">Hop on a shared whiteboard room with WebRTC audio/video and real-time step derivations.</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="w-10 h-10 rounded-full bg-amber-500 text-white font-bold mx-auto mb-3 flex items-center justify-center">3</div>
          <h3 className="font-bold text-sm mb-1 text-slate-900 dark:text-white">Release Tokens & Rate</h3>
          <p className="text-xs text-slate-500">Mentors earn honorarium and volunteer certificates. Students build concept confidence.</p>
        </div>
      </div>

      <button onClick={onGetStarted} className="px-6 py-3 rounded-xl font-semibold text-xs text-white bg-[#4F46E5] hover:bg-[#4338CA]">
        Start Exploring Tutors
      </button>
    </div>
  );
}

// =========================================================================
// DUAL DASHBOARD VIEW
// =========================================================================
function DualDashboardView({
  role,
  studentCoins,
  setStudentCoins,
  upcomingSessions,
  enrolledBatches,
  pendingRequests,
  onAcceptRequest,
  onDeclineRequest,
  onJoinLive
}) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white ${role === 'student' ? 'bg-[#4F46E5]' : 'bg-emerald-600'
            }`}>
            <Icon name={role === 'student' ? "graduation-cap" : "shield-check"} className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              {role === 'student' ? 'Student Workspace' : 'Mentor Command Center'}
            </h1>
            <p className="text-xs text-slate-500">
              {role === 'student' ? 'Manage your doubt bookings, enrolled batches & token balance.' : 'Manage student doubt requests, honorarium payouts & live sessions.'}
            </p>
          </div>
        </div>

        {role === 'student' ? (
          <div className="flex items-center gap-3">
            <div className="px-3.5 py-1.5 rounded-xl bg-amber-500/10 text-amber-600 font-bold text-xs flex items-center gap-1.5">
              <Icon name="coins" className="w-4 h-4 text-amber-500" />
              <span>{studentCoins} Tokens</span>
            </div>
            <button
              onClick={() => setStudentCoins(studentCoins + 100)}
              className="px-3 py-1.5 rounded-xl text-xs font-bold text-white bg-[#4F46E5] hover:bg-[#4338CA]"
            >
              + Get Tokens
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <div className="px-3.5 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 font-bold text-xs">
              Payout: ₹4,350 (1,450 XP)
            </div>
            <button
              onClick={() => alert("Simulated Payout: ₹4,350 sent to registered UPI ID!")}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700"
            >
              Withdraw to UPI
            </button>
          </div>
        )}
      </div>

      {role === 'student' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white mb-3">Upcoming 1:1 Live Calls</h2>
              {upcomingSessions.map(s => (
                <div key={s.id} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-xs text-slate-900 dark:text-white">{s.mentorName} ({s.college})</div>
                    <div className="text-xs text-[#4F46E5] font-semibold">{s.topic}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{s.time}</div>
                  </div>
                  <button
                    onClick={onJoinLive}
                    className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm flex items-center gap-1.5"
                  >
                    <Icon name="video" className="w-3.5 h-3.5" />
                    <span>Join Room</span>
                  </button>
                </div>
              ))}
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white mb-3">My Enrolled Batches</h2>
              {enrolledBatches.map(b => (
                <div key={b.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">{b.title}</div>
                    <div className="text-slate-400">{b.schedule}</div>
                  </div>
                  <button onClick={onJoinLive} className="text-xs font-bold text-[#4F46E5] hover:underline">
                    Classroom →
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-2">Need Help Right Now?</h3>
              <p className="text-xs text-slate-500 mb-4">Launch our live whiteboard and match with an active mentor.</p>
              <button
                onClick={onJoinLive}
                className="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-[#4F46E5] hover:bg-[#4338CA]"
              >
                Launch Instant Room
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
              <h2 className="font-bold text-sm text-slate-900 dark:text-white mb-3">Pending Doubt Requests</h2>
              {pendingRequests.map(r => (
                <div key={r.id} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-bold text-xs text-slate-900 dark:text-white">{r.studentName} ({r.grade})</div>
                    <div className="text-xs font-semibold text-[#4F46E5]">{r.topic}</div>
                    <div className="text-[11px] text-slate-400">{r.time} • Offer: {r.tokenOffer}</div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button onClick={() => onDeclineRequest(r)} className="px-2.5 py-1.5 text-xs text-slate-500 hover:bg-slate-200 rounded-lg">
                      Decline
                    </button>
                    <button onClick={() => onAcceptRequest(r)} className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#4F46E5] hover:bg-[#4338CA] rounded-xl">
                      Accept
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm text-xs space-y-2">
              <div className="font-bold text-slate-900 dark:text-white">College Status: Verified </div>
              <div className="text-slate-500">IIT Bombay • 2022ME10452</div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between">
                <span>Total Hours:</span>
                <span className="font-bold">64.5 hrs</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// =========================================================================
// INTERACTIVE LIVE CLASSROOM (`/live-room`) - FULL SCREEN HD VIRTUAL CLASSROOM
// =========================================================================
function LiveClassroomMock({ onExit, mentor, showToast }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [activeTool, setActiveTool] = useState('pen');
  const [color, setColor] = useState('#4F46E5');
  const [lineWidth, setLineWidth] = useState(3);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCamOn, setIsCamOn] = useState(true);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [messages, setMessages] = useState([
    { id: 1, sender: mentor ? mentor.name : "Rahul Sharma", text: "Welcome! Let's solve the definite integral problem using by-parts.", time: "14:15", isMentor: true },
    { id: 2, sender: "You (Student)", text: "Sir, does the cyclic integration trick apply for e^x·sin(x)?", time: "14:18", isMentor: false }
  ]);
  const [chatInput, setChatInput] = useState('');

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const renderWhiteboard = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const rect = parent.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;

      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;

      const ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);

      // Clean White Canvas
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, rect.width, rect.height);

      // Crisp Light Grid Pattern
      ctx.strokeStyle = "#F1F5F9";
      ctx.lineWidth = 1;
      const step = 32;
      for (let x = 0; x < rect.width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, rect.height);
        ctx.stroke();
      }
      for (let y = 0; y < rect.height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(rect.width, y);
        ctx.stroke();
      }

      // Title & Formula Container
      const boxW = Math.min(rect.width - 60, 660);
      ctx.fillStyle = "#EEF2FF";
      if (ctx.roundRect) {
        ctx.beginPath();
        ctx.roundRect(40, 24, boxW, 60, 16);
        ctx.fill();
        ctx.strokeStyle = "#C7D2FE";
        ctx.lineWidth = 1.5;
        ctx.stroke();
      } else {
        ctx.fillRect(40, 24, boxW, 60);
      }

      ctx.font = "bold 19px 'Plus Jakarta Sans', sans-serif";
      ctx.fillStyle = "#4338CA";
      ctx.fillText("∫ u · v dx  =  u · ∫ v dx  -  ∫ ( u' · ∫ v dx ) dx", 60, 60);

      // Worked Example Step by Step
      ctx.font = "600 15px 'Inter', sans-serif";
      ctx.fillStyle = "#0F172A";
      ctx.fillText("Example: Evaluate  I = ∫ x · sin(x) dx", 60, 118);

      ctx.font = "500 14px 'Inter', sans-serif";
      ctx.fillStyle = "#047857";
      ctx.fillText("Step 1: Choose u = x  &  v = sin(x)", 60, 146);

      ctx.fillStyle = "#0369A1";
      ctx.fillText("Step 2: u' = 1  and  ∫ sin(x) dx = -cos(x)", 60, 172);

      ctx.font = "bold 16px 'Plus Jakarta Sans', sans-serif";
      ctx.fillStyle = "#4F46E5";
      ctx.fillText("Result:  I = -x · cos(x) + sin(x) + C   ", 60, 208);
    };

    renderWhiteboard();
    window.addEventListener('resize', renderWhiteboard);
    return () => window.removeEventListener('resize', renderWhiteboard);
  }, []);

  const getCanvasCoords = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    const clientY = e.clientY || (e.touches && e.touches[0].clientY) || 0;
    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  };

  const startDrawing = (e) => {
    const canvas = canvasRef.current;
    const coords = getCanvasCoords(e);
    // ctx.scale(dpr, dpr) is already applied during init, so coords are in CSS-pixel space — do NOT multiply by dpr again
    const ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    setIsDrawing(true);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const coords = getCanvasCoords(e);
    const ctx = canvas.getContext('2d');
    // lineWidth is in CSS pixels — ctx.scale handles the DPR mapping
    ctx.lineWidth = activeTool === 'eraser' ? 28 : lineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = activeTool === 'eraser' ? '#FFFFFF' : color;
    ctx.lineTo(coords.x, coords.y);
    ctx.stroke();
  };

  const stopDrawing = () => setIsDrawing(false);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    // canvas.width/height are physical pixels; divide by dpr to get CSS pixels (which is what the scaled context expects)
    const dpr = window.devicePixelRatio || 1;
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, canvas.width / dpr, canvas.height / dpr);
  };

  const handleSend = (e) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg = chatInput;
    setMessages(prev => [...prev, {
      id: Date.now(),
      sender: "You (Student)",
      text: userMsg,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMentor: false
    }]);
    setChatInput('');

    // Mentor auto response simulator
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        sender: mentor ? mentor.name : "Rahul Sharma",
        text: `Great question! Yes, for cyclic integrals like e^x·sin(x), we apply by-parts twice and group the integral on the LHS. Let me write it on the whiteboard!`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isMentor: true
      }]);
    }, 1400);
  };

  const activeMentor = mentor || {
    name: "Rahul Sharma",
    college: "IIT Bombay",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80"
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950 text-white overflow-hidden font-sans">
      {/* 1. TOP HEADER BANNER */}
      <div className="h-14 px-4 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 flex items-center justify-between z-30 shadow-md">
        <div className="flex items-center space-x-3">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-mono font-bold">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
            <span>LIVE REC • 14:22</span>
          </div>
          
          <div className="h-4 w-px bg-slate-800 hidden sm:block"></div>

          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-white">Calculus Live Doubt Room</span>
            <span className="px-2 py-0.5 rounded-md bg-indigo-950 text-indigo-400 text-[11px] font-semibold border border-indigo-800/60">
              {activeMentor.name} ({activeMentor.college || 'IIT Bombay'})
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => { setIsHandRaised(!isHandRaised); showToast(isHandRaised ? "Hand Lowered" : "Hand Raised to Mentor!", ""); }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              isHandRaised ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-300' : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
            }`}
          >
            <span></span>
            <span className="hidden sm:inline">{isHandRaised ? 'Hand Raised' : 'Raise Hand'}</span>
          </button>

          <button
            onClick={onExit}
            className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-xs font-bold text-white shadow-lg shadow-rose-600/30 transition-all"
          >
            Leave Session
          </button>
        </div>
      </div>

      {/* 2. MAIN WORKSPACE CONTAINER */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        
        {/* WHITEBOARD CANVAS CONTAINER */}
        <div className="flex-1 flex flex-col relative bg-white overflow-hidden">
          
          {/* Floating Whiteboard Control Toolbar */}
          <div className="absolute top-4 left-4 z-20 flex items-center gap-2 p-1.5 rounded-2xl bg-slate-900/90 backdrop-blur-xl text-white shadow-2xl border border-slate-700/80">
            <button
              onClick={() => setActiveTool('pen')}
              className={`p-2 rounded-xl transition-all ${activeTool === 'pen' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
              title="Pen Tool"
            >
              <Icon name="pen-tool" className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveTool('eraser')}
              className={`p-2 rounded-xl transition-all ${activeTool === 'eraser' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
              title="Eraser"
            >
              <Icon name="eraser" className="w-4 h-4" />
            </button>

            <div className="h-4 w-px bg-slate-800"></div>

            {/* Colors */}
            <div className="flex items-center gap-1.5 px-1">
              {['#4F46E5', '#10B981', '#DC2626', '#0F172A'].map(c => (
                <button
                  key={c}
                  onClick={() => { setColor(c); setActiveTool('pen'); }}
                  className={`w-5 h-5 rounded-full transition-transform ${color === c && activeTool === 'pen' ? 'scale-125 ring-2 ring-white' : 'opacity-80 hover:opacity-100'}`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>

            <div className="h-4 w-px bg-slate-800"></div>

            <button
              onClick={clearCanvas}
              className="px-2.5 py-1 text-xs text-rose-400 font-bold hover:bg-rose-950/40 rounded-lg transition-colors"
            >
              Clear
            </button>
          </div>

          {/* Crisp HTML5 Canvas */}
          <canvas
            ref={canvasRef}
            id="whiteboard-canvas"
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className="w-full h-full block cursor-crosshair"
          />

          {/* FLOATING WEBCAM SPEAKER BAR (Bottom Left Overlay) */}
          <div className="absolute bottom-4 left-4 z-20 flex items-center gap-3 p-2 rounded-2xl bg-slate-950/80 backdrop-blur-xl border border-slate-800 shadow-2xl">
            {/* Mentor Tile */}
            <div className="w-44 h-28 rounded-xl bg-slate-900 border-2 border-indigo-500 overflow-hidden relative shadow-md group">
              <img src={activeMentor.avatar} alt="Mentor" className="w-full h-full object-cover" />
              <div className="absolute bottom-1.5 left-2 right-2 flex items-center justify-between text-[10px] bg-slate-950/80 backdrop-blur-sm px-2 py-0.5 rounded-lg border border-slate-800 text-white font-medium">
                <span className="truncate max-w-[90px]">{activeMentor.name}</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Mic
                </span>
              </div>
            </div>

            {/* Student Tile */}
            <div className="w-36 h-28 rounded-xl bg-slate-900 border-2 border-slate-700 overflow-hidden relative shadow-md">
              {isCamOn ? (
                <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80" alt="You" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-xs text-slate-500 bg-slate-900">
                  <Icon name="video-off" className="w-5 h-5 mb-1 text-slate-600" />
                  <span>Cam Off</span>
                </div>
              )}

              {isHandRaised && (
                <span className="absolute top-1.5 right-1.5 bg-amber-400 text-slate-950 text-[10px] font-extrabold px-1.5 py-0.5 rounded-md shadow-md animate-bounce">
                   Hand
                </span>
              )}

              <div className="absolute bottom-1.5 left-2 right-2 flex items-center justify-between text-[10px] bg-slate-950/80 backdrop-blur-sm px-2 py-0.5 rounded-lg border border-slate-800 text-white font-medium">
                <span>You</span>
                <span className={isMicOn ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                  {isMicOn ? 'On' : 'Muted'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 3. RIGHT SIDEBAR (Live Doubt Chat & Controls) */}
        <div className="w-full lg:w-80 bg-slate-900 border-l border-slate-800 flex flex-col justify-between z-20">
          
          <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white">Live Doubt Chat</span>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-950 text-indigo-400 rounded-full border border-indigo-800/60">
                {messages.length} msgs
              </span>
            </div>
            <div className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              Connected
            </div>
          </div>

          {/* Message History */}
          <div className="flex-1 p-3.5 space-y-3 overflow-y-auto text-xs">
            {messages.map(m => (
              <div
                key={m.id}
                className={`p-3 rounded-2xl border transition-all ${
                  m.isMentor
                    ? 'bg-indigo-950/50 border-indigo-800/60 text-indigo-100'
                    : 'bg-slate-800/80 border-slate-700/60 text-slate-200'
                }`}
              >
                <div className="flex justify-between items-center text-[10px] mb-1">
                  <span className={`font-bold ${m.isMentor ? 'text-indigo-400' : 'text-slate-400'}`}>
                    {m.isMentor ? ` ${m.sender}` : m.sender}
                  </span>
                  <span className="text-slate-500">{m.time}</span>
                </div>
                <p className="leading-relaxed text-xs">{m.text}</p>
              </div>
            ))}
          </div>

          {/* Quick Reaction Pills */}
          <div className="px-3 py-1.5 border-t border-slate-800/60 flex items-center gap-1.5 overflow-x-auto bg-slate-950/30">
            <button
              onClick={() => handleSend({ preventDefault: () => {}, target: {} }, "Got it! Thanks sir ")}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 font-medium whitespace-nowrap"
            >
               Got it!
            </button>
            <button
              onClick={() => handleSend({ preventDefault: () => {}, target: {} }, "Can you explain step 2 again?")}
              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 font-medium whitespace-nowrap"
            >
               Explain Step 2
            </button>
          </div>

          {/* Chat Input & Media Controls */}
          <div className="p-3 border-t border-slate-800 space-y-2 bg-slate-950">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => { setIsMicOn(!isMicOn); showToast(isMicOn ? "Microphone Muted" : "Microphone Unmuted", isMicOn ? "" : ""); }}
                className={`py-1.5 text-xs font-bold rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                  isMicOn ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' : 'bg-rose-950/60 border-rose-800 text-rose-400'
                }`}
              >
                <span>{isMicOn ? ' Mute' : ' Unmute'}</span>
              </button>

              <button
                onClick={() => { setIsCamOn(!isCamOn); showToast(isCamOn ? "Camera Turned Off" : "Camera Turned On", isCamOn ? "" : ""); }}
                className={`py-1.5 text-xs font-bold rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                  isCamOn ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' : 'bg-rose-950/60 border-rose-800 text-rose-400'
                }`}
              >
                <span>{isCamOn ? ' Stop Cam' : ' Start Cam'}</span>
              </button>
            </div>

            <form onSubmit={handleSend} className="flex gap-2 pt-1">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask doubt in live class..."
                className="flex-1 px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md flex items-center justify-center"
              >
                <Icon name="send" className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>

        </div>
      </div>
    </div>
  );
}

// =========================================================================
// BOOKING & PROFILE MODALS
// =========================================================================
function BookingModal({ mentor, onClose, onConfirm }) {
  const [selectedDate, setSelectedDate] = useState('Tomorrow');
  const [selectedSlot, setSelectedSlot] = useState('05:30 PM');
  const [topic, setTopic] = useState('');

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 border border-slate-200 dark:border-slate-800">
        <div className="flex justify-between items-center">
          <div className="font-bold text-sm text-slate-900 dark:text-white">Book 1:1 with {mentor.name}</div>
          <button onClick={onClose}><Icon name="x" className="w-4 h-4 text-slate-400" /></button>
        </div>

        <div>
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Select Day</label>
          <div className="grid grid-cols-4 gap-1.5">
            {['Today', 'Tomorrow', 'Friday', 'Saturday'].map(d => (
              <button
                key={d}
                onClick={() => setSelectedDate(d)}
                className={`py-1.5 text-xs font-semibold rounded-xl border ${selectedDate === d ? 'bg-[#4F46E5] text-white border-[#4F46E5]' : 'border-slate-200 dark:border-slate-800'}`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Time Slot</label>
          <div className="grid grid-cols-3 gap-1.5">
            {['04:00 PM', '05:30 PM', '07:00 PM'].map(s => (
              <button
                key={s}
                onClick={() => setSelectedSlot(s)}
                className={`py-1.5 text-xs font-semibold rounded-xl border ${selectedSlot === s ? 'bg-emerald-600 text-white border-emerald-600' : 'border-slate-200 dark:border-slate-800'}`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">Doubt Topic</label>
          <input
            type="text"
            placeholder="e.g. Integration by parts, Rotational Torque..."
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            className="w-full p-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
          />
        </div>

        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold">{mentor.hourlyRate === 0 ? 'Free' : `₹${mentor.hourlyRate}`}</span>
          <button
            onClick={() => onConfirm({ date: selectedDate, time: selectedSlot, topic })}
            className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#4F46E5] hover:bg-[#4338CA]"
          >
            Confirm Booking
          </button>
        </div>
      </div>
    </div>
  );
}

function MentorProfileModal({ mentor, onClose, onBook }) {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 border border-slate-200 dark:border-slate-800">
        <div className="flex justify-between items-start">
          <div className="flex gap-3">
            <img src={mentor.avatar} alt={mentor.name} className="w-14 h-14 rounded-2xl object-cover" />
            <div>
              <div className="flex items-center gap-1 font-bold text-sm text-slate-900 dark:text-white">
                <span>{mentor.name}</span>
                <Icon name="shield-check" className="w-4 h-4 text-blue-500" />
              </div>
              <div className="text-xs text-slate-500">{mentor.college} • {mentor.year}</div>
              <div className="text-xs text-amber-500 font-bold mt-0.5"> {mentor.rating} ({mentor.reviewsCount} reviews)</div>
            </div>
          </div>
          <button onClick={onClose}><Icon name="x" className="w-4 h-4 text-slate-400" /></button>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{mentor.bio}</p>

        <div>
          <div className="text-xs font-bold text-slate-400 mb-1.5">Expertise</div>
          <div className="flex flex-wrap gap-1.5">
            {mentor.subjects.map(s => (
              <span key={s} className="text-xs px-2.5 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5]">
                {s}
              </span>
            ))}
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold">{mentor.hourlyRate === 0 ? 'Free (Volunteer)' : `₹${mentor.hourlyRate}/hr`}</span>
          <button onClick={onBook} className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#4F46E5] hover:bg-[#4338CA]">
            Book 1:1 Live
          </button>
        </div>
      </div>
    </div>
  );
}

// Render React 18
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
